"use client";
import Link from "next/link";
import { useEffect, useState } from "react";
import { useCart } from "@/lib/cart/cart";
import type { CartQuote } from "@/lib/cart/types";
import { formatMoney } from "@/lib/money";

// Server-priced bag summary. `editable` shows quantity controls (cart page).
export default function CartSummary({ editable = false }: { editable?: boolean }) {
  const { items, ready, setQuantity, remove } = useCart();
  const [quote, setQuote] = useState<CartQuote | null>(null);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    if (!ready) return;
    const controller = new AbortController();
    fetch("/api/cart", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ items }),
      signal: controller.signal,
    })
      .then((r) => r.json())
      .then((d) => {
        setQuote(d.quote ?? null);
        setError(d.error ?? null);
      })
      .catch(() => {});
    return () => controller.abort();
  }, [items, ready]);

  if (!ready) return null;
  if (items.length === 0) return <p>Your bag is empty. <Link href="/shop">Continue shopping</Link></p>;

  return (
    <div style={{ display: "grid", gap: 12 }}>
      {error && <p role="alert" style={{ color: "#b3261e" }}>{error}</p>}
      {!quote && !error && [0, 1].map((i) => (
        <div key={i} className="motion-shimmer" style={{ height: 48, borderRadius: 6 }} />
      ))}
      {quote?.lines.map((line) => {
        const item = items.find((i) => i.variantId === line.variantId && (i.engraving ?? "") === (line.engraving ?? ""));
        return (
          <div key={`${line.variantId}-${line.engraving ?? ""}`} className="motion-fade-up" style={{ display: "flex", justifyContent: "space-between", gap: 12 }}>
            <div>
              <Link href={`/products/${line.slug}`}>{line.name}</Link>
              <div style={{ fontSize: 13, color: "#6b665e" }}>{line.description}</div>
              {line.engraving && <div style={{ fontSize: 13 }}>Engraving: “{line.engraving}”</div>}
              {editable && item ? (
                <div style={{ display: "flex", gap: 8, alignItems: "center", marginTop: 6 }}>
                  <button type="button" aria-label="Decrease quantity" onClick={() => setQuantity(item, item.quantity - 1)}>−</button>
                  <span>{item.quantity}</span>
                  <button type="button" aria-label="Increase quantity" onClick={() => setQuantity(item, Math.min(10, item.quantity + 1))}>+</button>
                  <button type="button" onClick={() => remove(item)}>Remove</button>
                </div>
              ) : (
                <div style={{ fontSize: 13 }}>Qty {line.quantity}</div>
              )}
            </div>
            <div>{formatMoney(line.lineTotalMinor, quote.currency)}</div>
          </div>
        );
      })}
      {quote && (
        <dl style={{ display: "grid", gridTemplateColumns: "1fr auto", gap: 4, borderTop: "1px solid #e6e1d8", paddingTop: 12 }}>
          <dt>Subtotal</dt><dd style={{ margin: 0 }}>{formatMoney(quote.subtotalMinor, quote.currency)}</dd>
          <dt>Insured shipping</dt><dd style={{ margin: 0 }}>{quote.shippingMinor ? formatMoney(quote.shippingMinor, quote.currency) : "Free"}</dd>
          <dt>Tax</dt><dd style={{ margin: 0 }}>{formatMoney(quote.taxMinor, quote.currency)}</dd>
          <dt style={{ fontWeight: 600 }}>Total</dt><dd style={{ margin: 0, fontWeight: 600 }}>{formatMoney(quote.totalMinor, quote.currency)}</dd>
        </dl>
      )}
    </div>
  );
}
