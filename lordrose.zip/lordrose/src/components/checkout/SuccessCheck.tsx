// Gold checkmark that draws itself, with a few sparkles — shown when an order is confirmed.
export default function SuccessCheck() {
  return (
    <div className="success-check" aria-hidden="true">
      <svg viewBox="0 0 64 64">
        <circle className="success-check__circle" cx="32" cy="32" r="28" fill="none" stroke="currentColor" strokeWidth="3" pathLength={1} />
        <path
          className="success-check__tick"
          d="M20 33 L28 41 L44 23"
          fill="none"
          stroke="currentColor"
          strokeWidth="4"
          strokeLinecap="round"
          strokeLinejoin="round"
          pathLength={1}
        />
      </svg>
      <span className="success-check__sparkle" />
      <span className="success-check__sparkle" />
      <span className="success-check__sparkle" />
      <span className="success-check__sparkle" />
    </div>
  );
}
