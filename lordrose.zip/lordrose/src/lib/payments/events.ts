import "server-only";
import { Prisma } from "@prisma/client";
import { prisma } from "@/lib/db/prisma";
import { applyPaymentStatus } from "@/lib/orders/orders";
import { statusFromPaymentHistory } from "./history";
import { findPaymentByReference } from "./worldpay/queries";
import type { WorldpayEvent } from "./worldpay/webhooks";

// A webhook only tells us "something happened to payment X". We never trust its body:
// we look the payment up with Worldpay's Payment Queries API and use that answer.
// Safe to run twice — statuses never move backwards and an order is marked paid only once.
export async function processEvent(event: WorldpayEvent) {
  const reference = event.eventDetails.transactionReference;
  if (!reference) return;

  if (await prisma.paymentEvent.findUnique({ where: { eventId: event.eventId } })) return;

  const payment = await prisma.payment.findUnique({ where: { transactionRef: reference } });
  if (!payment) {
    console.warn("Worldpay event for unknown transactionReference", reference, event.eventDetails.type);
    return;
  }

  const remote = await findPaymentByReference(reference);
  if (!remote) throw new Error(`Worldpay has no payment for ${reference} yet`); // 500 → Worldpay retries later

  const value = remote.value;
  if (value && (value.amount !== payment.amountMinor || value.currency !== payment.currency)) {
    console.error("Worldpay amount does not match order — not updating", reference, value, payment.amountMinor);
  } else {
    const next = statusFromPaymentHistory(remote.events ?? [], payment.amountMinor);
    if (next) await applyPaymentStatus(payment.id, next, { worldpayPaymentId: remote.paymentId, raw: remote });
  }

  try {
    await prisma.paymentEvent.create({
      data: {
        paymentId: payment.id,
        eventId: event.eventId,
        eventType: event.eventDetails.type,
        payload: event as unknown as Prisma.InputJsonValue,
      },
    });
  } catch (e) {
    if (!(e instanceof Prisma.PrismaClientKnownRequestError && e.code === "P2002")) throw e;
  }
}
