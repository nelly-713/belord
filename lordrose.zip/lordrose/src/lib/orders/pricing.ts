import "server-only";
import { prisma } from "@/lib/db/prisma";
import { shippingFor } from "@/lib/shipping/rates";
import type { CartItem, CartQuote } from "@/lib/cart/types";

export class PricingError extends Error {}

// The only place prices are calculated. Never trust prices sent from the browser.
export async function priceCart(items: CartItem[]): Promise<CartQuote> {
  if (items.length === 0) throw new PricingError("Your bag is empty.");

  const variants = await prisma.variant.findMany({
    where: { id: { in: items.map((i) => i.variantId) } },
    include: { product: true },
  });
  const byId = new Map(variants.map((v) => [v.id, v]));

  const requested = new Map<string, number>();
  for (const item of items) requested.set(item.variantId, (requested.get(item.variantId) ?? 0) + item.quantity);

  const lines = items.map((item) => {
    const v = byId.get(item.variantId);
    if (!v) throw new PricingError("An item in your bag is no longer available.");
    if (v.stock < (requested.get(v.id) ?? 0)) {
      throw new PricingError(v.stock > 0 ? `Only ${v.stock} left of ${v.product.name}.` : `${v.product.name} is sold out.`);
    }
    const engraving = item.engraving?.trim() || null;
    if (engraving && !v.product.engravable) throw new PricingError(`${v.product.name} can't be engraved.`);
    return {
      variantId: v.id,
      sku: v.sku,
      name: v.product.name,
      slug: v.product.slug,
      description: [v.metal, v.size && `Size ${v.size}`, v.gemstone].filter(Boolean).join(" · "),
      quantity: item.quantity,
      unitPriceMinor: v.priceMinor,
      lineTotalMinor: v.priceMinor * item.quantity,
      engraving,
      currency: v.currency,
    };
  });

  const currencies = new Set(lines.map((l) => l.currency));
  if (currencies.size > 1) throw new PricingError("Items in your bag are priced in different currencies.");

  const subtotalMinor = lines.reduce((sum, l) => sum + l.lineTotalMinor, 0);
  const shippingMinor = shippingFor(subtotalMinor);
  const taxMinor = 0; // TODO: sales tax / VAT (use a tax service such as a tax-rates API by destination)

  return {
    lines: lines.map(({ currency: _c, ...line }) => line),
    currency: lines[0].currency,
    subtotalMinor,
    shippingMinor,
    taxMinor,
    totalMinor: subtotalMinor + shippingMinor + taxMinor,
  };
}
