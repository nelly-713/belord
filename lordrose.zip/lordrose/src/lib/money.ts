// Assumes two-decimal currencies (USD, GBP, EUR...). Adjust for JPY etc.
export function formatMoney(minor: number, currency: string) {
  return new Intl.NumberFormat("en-US", { style: "currency", currency }).format(minor / 100);
}
