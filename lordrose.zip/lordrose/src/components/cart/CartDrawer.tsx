export default function CartDrawer() {
  return <div>{/* TODO: CartDrawer */}</div>;
}
