#!/usr/bin/env bash
# Puts this project in a new private GitHub repository and pushes it.
# Usage (from the project folder):  bash scripts/push-to-github.sh [repo-name]   (default: lordrose)
set -euo pipefail

REPO="${1:-lordrose}"

if [ ! -f package.json ] || [ ! -f prisma/schema.prisma ]; then
  echo "Run this from the project folder (the one with package.json)." >&2
  exit 1
fi
for cmd in git node npm; do
  command -v "$cmd" >/dev/null || { echo "$cmd is required — install it first." >&2; exit 1; }
done

echo "==> Installing packages (also records exact versions so Cloudflare builds the same thing)"
npm install

if ! ls prisma/migrations/*/migration.sql >/dev/null 2>&1; then
  echo "==> Creating the first database migration"
  mkdir -p prisma/migrations/0_init
  DATABASE_URL="${DATABASE_URL:-postgresql://user:pass@localhost:5432/placeholder}" \
  DATABASE_URL_UNPOOLED="${DATABASE_URL_UNPOOLED:-postgresql://user:pass@localhost:5432/placeholder}" \
    npx prisma migrate diff --from-empty --to-schema-datamodel prisma/schema.prisma --script > prisma/migrations/0_init/migration.sql
  printf 'provider = "postgresql"\n' > prisma/migrations/migration_lock.toml
fi

[ -d .git ] || git init -b main >/dev/null

if [ -z "$(git config user.name || true)" ] || [ -z "$(git config user.email || true)" ]; then
  read -r -p "Your name (for the commit history): " gname
  read -r -p "Your email (for the commit history): " gemail
  git config user.name "$gname"
  git config user.email "$gemail"
fi

git add -A

# Never upload passwords or local settings
leaked="$(git diff --cached --name-only | grep -E '(^|/)\.env($|\.)' | grep -v '\.env\.example$' || true)"
if [ -n "$leaked" ]; then
  echo "Stopping: these private files would be uploaded:" >&2
  echo "$leaked" >&2
  git reset -q
  exit 1
fi

if ! git diff --cached --quiet; then
  if git rev-parse --verify HEAD >/dev/null 2>&1; then
    git commit -q -m "Update Lord Rose store"
  else
    git commit -q -m "Lord Rose store: initial version"
  fi
fi

if git remote get-url origin >/dev/null 2>&1; then
  echo "==> Pushing to $(git remote get-url origin)"
  git push -u origin HEAD
elif command -v gh >/dev/null && gh auth status >/dev/null 2>&1; then
  echo "==> Creating private repository '$REPO' on GitHub"
  gh repo create "$REPO" --private --source=. --remote=origin --push
else
  echo
  echo "Create an EMPTY private repository on GitHub (no README, no .gitignore):"
  echo "  https://github.com/new   name: $REPO   visibility: Private"
  read -r -p "Then paste its URL here (https://github.com/you/$REPO.git): " url
  git remote add origin "$url"
  git push -u origin HEAD
fi

echo
echo "Done. Next: connect the repository in Cloudflare (see README → 'Automatic deploys')."
