export default function ShippingOptions() {
  return <div>{/* TODO: ShippingOptions */}</div>;
}
