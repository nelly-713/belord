import Link from "next/link";
import type { Metadata } from "next";
import { brand } from "@/content/brand";

export const metadata: Metadata = { title: "About" };

export default function AboutPage() {
  const { about } = brand;
  return (
    <main>
      <div className="lr-about-hero" role="img" aria-label="A cushion-cut diamond on gold" />
      <section className="lr-section">
        <div className="lr-wrap lr-split" style={{ alignItems: "start" }}>
          <div className="lr-split__body">
            <p className="lr-eyebrow">{about.eyebrow}</p>
            <h1 style={{ margin: 0, fontSize: "clamp(34px, 5vw, 56px)" }}>{about.title}</h1>
          </div>
          <div className="lr-prose">
            {about.paragraphs.map((p, i) => <p key={i}>{p}</p>)}
            <p className="lr-signature">{about.founder.name}</p>
            <p className="lr-eyebrow" style={{ marginTop: 4 }}>{about.founder.role}</p>
            <div style={{ marginTop: 32 }}><Link className="lr-btn lr-btn--dark" href="/shop">Explore the boutique</Link></div>
          </div>
        </div>
      </section>
    </main>
  );
}
