#!/usr/bin/env bash
# Puts the store live on Cloudflare Workers at lordrose.com (registration stays at IONOS;
# nellycreativestudios.com is not touched).
#
# Before running (one time, by hand):
#   1. Cloudflare: Add a domain → lordrose.com → Free plan. In the DNS records it imports, delete the
#      A / AAAA / CNAME records for "lordrose.com" and "www" (IONOS parking page). Keep MX and TXT (email).
#   2. IONOS: Domains & SSL → lordrose.com → Name servers → use custom name servers → enter the two
#      Cloudflare gives you. Wait until Cloudflare shows lordrose.com as "Active".
#   3. Cloudflare: Workers & Pages → Plans → Workers Paid ($5/month).
#   4. Neon (neon.com): create a free project; keep its two connection strings handy
#      (Connect → "Connection pooling" ON = pooled, OFF = direct).
#   5. .env has your Worldpay Try credentials.
#
# Usage (from the project root):
#   bash deploy-cloudflare.sh              # everything
#   bash deploy-cloudflare.sh --code-only  # just the code changes
set -euo pipefail

DOMAIN="lordrose.com"
WORKER="lordrose"
SITE_URL="https://$DOMAIN"
CODE_ONLY=false
[ "${1:-}" = "--code-only" ] && CODE_ONLY=true
SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"

if [ ! -f prisma/schema.prisma ] || [ ! -f src/lib/payments/worldpay/client.ts ]; then
  echo "Run this from the store's project folder (after build-worldpay-checkout.sh)." >&2
  exit 1
fi
command -v node >/dev/null || { echo "Node.js is required" >&2; exit 1; }

w() { mkdir -p "$(dirname "$1")"; cat > "$1"; }

echo "==> 1/3 Code changes for Cloudflare"

# Production fixes from deploy-lordrose.sh (webhook check via Payment Queries, migrations, etc.)
if [ ! -f src/lib/payments/history.ts ]; then
  for f in ./deploy-lordrose.sh "$SCRIPT_DIR/deploy-lordrose.sh"; do
    if [ -f "$f" ]; then bash "$f" --code-only; break; fi
  done
  [ -f src/lib/payments/history.ts ] || {
    echo "Put deploy-lordrose.sh next to this script (it carries the webhook fix), then run again." >&2
    exit 1
  }
fi

# Database client: Cloudflare Workers can't reuse a connection across requests,
# so on Neon we make one client per request. Local Postgres keeps the normal client.
w src/lib/db/prisma.ts <<'EOF'
import { cache } from "react";
import { PrismaClient } from "@prisma/client";
import { PrismaNeon } from "@prisma/adapter-neon";

const usesNeon = () => /\.neon\.tech\b/.test(process.env.DATABASE_URL ?? "");

function create() {
  const url = process.env.DATABASE_URL ?? "";
  return usesNeon() ? new PrismaClient({ adapter: new PrismaNeon({ connectionString: url }) }) : new PrismaClient();
}

const perRequest = cache(create);
const g = globalThis as unknown as { prisma?: PrismaClient };

function client(): PrismaClient {
  if (usesNeon()) return perRequest();
  return (g.prisma ??= create());
}

// Same `prisma` import as before; it picks the right client at call time.
export const prisma = new Proxy({} as PrismaClient, {
  get(_target, prop) {
    const c = client();
    const value = Reflect.get(c, prop);
    return typeof value === "function" ? value.bind(c) : value;
  },
});
EOF

# Web Crypto works everywhere (Node and Workers)
w src/lib/orders/order-number.ts <<'EOF'
// Short, unambiguous, customer-facing order numbers, e.g. JW-7KQ2MX9A.
const ALPHABET = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789";

export function generateOrderNumber(prefix = "JW") {
  const bytes = crypto.getRandomValues(new Uint8Array(8));
  let s = "";
  for (const b of bytes) s += ALPHABET[b % ALPHABET.length]; // 256 is a multiple of 32: no bias
  return `${prefix}-${s}`;
}
EOF

w open-next.config.ts <<'EOF'
import { defineCloudflareConfig } from "@opennextjs/cloudflare";

export default defineCloudflareConfig();
EOF

if ls next.config.* >/dev/null 2>&1; then
  echo "    next.config already exists — make sure it has serverExternalPackages: [\"@prisma/client\", \".prisma/client\"]"
  echo "    and a www.$DOMAIN → $DOMAIN redirect."
else
  w next.config.ts <<EOF
import type { NextConfig } from "next";

const nextConfig: NextConfig = {
  // Lets OpenNext bundle and patch Prisma for Cloudflare Workers.
  serverExternalPackages: ["@prisma/client", ".prisma/client"],
  async redirects() {
    return [
      {
        source: "/:path*",
        has: [{ type: "host", value: "www.$DOMAIN" }],
        destination: "$SITE_URL/:path*",
        permanent: true,
      },
    ];
  },
};

export default nextConfig;
EOF
fi

node - <<'EOF'
const fs = require("fs");
const edit = (file, fn) => {
  if (!fs.existsSync(file)) return;
  const before = fs.readFileSync(file, "utf8");
  const after = fn(before);
  if (after !== before) fs.writeFileSync(file, after);
};

edit("prisma/schema.prisma", (s) =>
  s.includes("driverAdapters")
    ? s
    : s.replace(/provider = "prisma-client-js"\n/, 'provider        = "prisma-client-js"\n  previewFeatures = ["driverAdapters"]\n')
);

edit("package.json", (s) => {
  const pkg = JSON.parse(s);
  pkg.dependencies = pkg.dependencies || {};
  pkg.devDependencies = pkg.devDependencies || {};
  pkg.dependencies["@prisma/client"] = "^6.16.0";
  pkg.devDependencies["prisma"] = "^6.16.0";
  pkg.dependencies["@prisma/adapter-neon"] = "^6.16.0";
  pkg.dependencies["@opennextjs/cloudflare"] = pkg.dependencies["@opennextjs/cloudflare"] || "^1.0.0";
  pkg.devDependencies["wrangler"] = pkg.devDependencies["wrangler"] || "^4.0.0";
  pkg.scripts = pkg.scripts || {};
  pkg.scripts.preview = "opennextjs-cloudflare build && opennextjs-cloudflare preview";
  pkg.scripts.deploy = "opennextjs-cloudflare build && opennextjs-cloudflare deploy";
  pkg.scripts["cf-typegen"] = "wrangler types --env-interface CloudflareEnv cloudflare-env.d.ts";
  return JSON.stringify(pkg, null, 2) + "\n";
});

edit(".gitignore", (s) => {
  const add = [".open-next", ".wrangler", ".dev.vars", ".env.cloudflare", ".env.production"].filter((l) => !s.split("\n").includes(l));
  return add.length ? s.trimEnd() + "\n" + add.join("\n") + "\n" : s;
});
EOF

if $CODE_ONLY; then
  echo "Code changes done (--code-only)."
  exit 0
fi

# ---------------------------------------------------------------------------
# 2. Cloudflare
# ---------------------------------------------------------------------------
echo "==> 2/3 Cloudflare"
[ -f .env ] || { echo "Create .env (copy .env.example) with your Worldpay Try credentials first." >&2; exit 1; }

envval() {
  node -e '
    const fs = require("fs");
    const file = process.argv[2] || ".env";
    if (!fs.existsSync(file)) process.exit(0);
    const m = fs.readFileSync(file, "utf8").match(new RegExp("^" + process.argv[1] + "=(.*)$", "m"));
    if (!m) process.exit(0);
    let v = m[1].trim();
    const q = v.match(/^"([^"]*)"/) || v.match(/^\x27([^\x27]*)\x27/);
    v = q ? q[1] : v.replace(/\s+#.*$/, "").trim();
    process.stdout.write(v);
  ' "$1" "${2:-.env}"
}

missing=()
for k in WORLDPAY_API_USERNAME WORLDPAY_API_PASSWORD WORLDPAY_ENTITY NEXT_PUBLIC_WORLDPAY_CHECKOUT_ID; do
  [ -n "$(envval "$k")" ] || missing+=("$k")
done
if [ ${#missing[@]} -gt 0 ]; then
  echo "Fill these in .env first (Worldpay Dashboard > Developer Tools, Try environment):" >&2
  printf '  - %s\n' "${missing[@]}" >&2
  exit 1
fi

read -r -p "Does Cloudflare show $DOMAIN as \"Active\" and are you on Workers Paid? [y/N] " ready
if [[ ! "$ready" =~ ^[Yy] ]]; then
  echo "Do steps 1–3 at the top of this script first, then run it again."
  exit 0
fi

# Neon connection strings, kept in .env.cloudflare (git-ignored) so reruns don't ask again
if [ -z "$(envval DATABASE_URL .env.cloudflare)" ]; then
  echo "Paste your Neon connection strings (they won't be shown):"
  read -r -s -p "  Pooled  (Connection pooling ON):  " pooled; echo
  read -r -s -p "  Direct  (Connection pooling OFF): " direct; echo
  case "$pooled$direct" in *neon.tech*) ;; *) echo "Those don't look like Neon connection strings." >&2; exit 1 ;; esac
  umask 077
  printf 'DATABASE_URL="%s"\nDATABASE_URL_UNPOOLED="%s"\n' "$pooled" "$direct" > .env.cloudflare
fi
DB_POOLED="$(envval DATABASE_URL .env.cloudflare)"
DB_DIRECT="$(envval DATABASE_URL_UNPOOLED .env.cloudflare)"

echo "    Installing packages"
npm install

if ! ls prisma/migrations/*/migration.sql >/dev/null 2>&1; then
  echo "    Creating the first database migration"
  mkdir -p prisma/migrations/0_init
  DATABASE_URL="$DB_POOLED" DATABASE_URL_UNPOOLED="$DB_DIRECT" \
    npx prisma migrate diff --from-empty --to-schema-datamodel prisma/schema.prisma --script > prisma/migrations/0_init/migration.sql
  printf 'provider = "postgresql"\n' > prisma/migrations/migration_lock.toml
fi

echo "    Setting up the database tables on Neon"
DATABASE_URL="$DB_POOLED" DATABASE_URL_UNPOOLED="$DB_DIRECT" npx prisma migrate deploy

narrative="$(envval WORLDPAY_NARRATIVE)"
if [ -z "$narrative" ] || [ "$narrative" = "JEWELRY STORE" ]; then narrative="LORDROSE.COM"; fi
WP_ENV="$(envval WORLDPAY_ENV)"; WP_ENV="${WP_ENV:-try}"
CHECKOUT_ID="$(envval NEXT_PUBLIC_WORLDPAY_CHECKOUT_ID)"
KEY_ID="$(envval WORLDPAY_WEBHOOK_KEY_ID)"

# Public values: baked into the browser code at build time, and readable by the server
cat > .env.production <<EOF
NEXT_PUBLIC_SITE_URL="$SITE_URL"
NEXT_PUBLIC_WORLDPAY_ENV="$WP_ENV"
NEXT_PUBLIC_WORLDPAY_CHECKOUT_ID="$CHECKOUT_ID"
EOF

WORKER="$WORKER" DOMAIN="$DOMAIN" SITE_URL="$SITE_URL" WP_ENV="$WP_ENV" CHECKOUT_ID="$CHECKOUT_ID" \
NARRATIVE="$narrative" KEY_ID="$KEY_ID" node - <<'EOF'
const fs = require("fs");
const e = process.env;
const config = {
  $schema: "node_modules/wrangler/config-schema.json",
  name: e.WORKER,
  main: ".open-next/worker.js",
  compatibility_date: "2025-09-01",
  compatibility_flags: ["nodejs_compat", "global_fetch_strictly_public"],
  assets: { directory: ".open-next/assets", binding: "ASSETS" },
  observability: { enabled: true },
  routes: [
    { pattern: e.DOMAIN, custom_domain: true },
    { pattern: `www.${e.DOMAIN}`, custom_domain: true },
  ],
  // Non-secret settings. Secrets (passwords, database) are stored with `wrangler secret`.
  vars: {
    NEXT_PUBLIC_SITE_URL: e.SITE_URL,
    NEXT_PUBLIC_WORLDPAY_ENV: e.WP_ENV,
    NEXT_PUBLIC_WORLDPAY_CHECKOUT_ID: e.CHECKOUT_ID,
    WORLDPAY_ENV: e.WP_ENV,
    WORLDPAY_NARRATIVE: e.NARRATIVE,
    ...(e.KEY_ID ? { WORLDPAY_WEBHOOK_KEY_ID: e.KEY_ID } : {}),
  },
};
fs.writeFileSync("wrangler.jsonc", JSON.stringify(config, null, 2) + "\n");
EOF

npx wrangler whoami >/dev/null 2>&1 || npx wrangler login

SECRETS_FILE="$(mktemp)"
cleanup() {
  rm -f "$SECRETS_FILE"
  if [ -f .env.deploy-backup ]; then mv .env.deploy-backup .env; fi
}
trap cleanup EXIT

# Build without your local .env so local/test values aren't packed into the live site.
# (.env.production supplies the public values; secrets are added below.)
echo "    Building and deploying (first build takes a few minutes)"
mv .env .env.deploy-backup
npm run deploy
mv .env.deploy-backup .env

echo "    Storing secrets"
WP_USER="$(envval WORLDPAY_API_USERNAME)" WP_PASS="$(envval WORLDPAY_API_PASSWORD)" WP_ENTITY="$(envval WORLDPAY_ENTITY)" \
WP_SECRET="$(envval WORLDPAY_WEBHOOK_SECRET)" DB_POOLED="$DB_POOLED" DB_DIRECT="$DB_DIRECT" node -e '
  const e = process.env;
  const s = {
    DATABASE_URL: e.DB_POOLED,
    DATABASE_URL_UNPOOLED: e.DB_DIRECT,
    WORLDPAY_API_USERNAME: e.WP_USER,
    WORLDPAY_API_PASSWORD: e.WP_PASS,
    WORLDPAY_ENTITY: e.WP_ENTITY,
  };
  if (e.WP_SECRET) s.WORLDPAY_WEBHOOK_SECRET = e.WP_SECRET;
  require("fs").writeFileSync(process.argv[1], JSON.stringify(s));
' "$SECRETS_FILE"
npx wrangler secret bulk "$SECRETS_FILE"

# ---------------------------------------------------------------------------
# 3. What's left
# ---------------------------------------------------------------------------
cat <<EOF

================================================================================
Live at $SITE_URL (test mode — Worldpay Try, no real money moves).

NEXT: Worldpay Dashboard (Try) > Developer Tools > Webhook
  URL: $SITE_URL/api/webhooks/worldpay
  Events: authorized, sentForSettlement, refused, cancelled, expired, error,
          sentForRefund, refundFailed

Cloudflare: leave Security > Bots > "Bot Fight Mode" OFF — it can block Worldpay's
webhook calls, and the free plan can't exempt one address from it.

To redeploy after code changes:  npm run deploy
================================================================================
EOF
