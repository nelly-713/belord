import Link from "next/link";
import CartSummary from "@/components/cart/CartSummary";
import CheckoutSteps from "@/components/checkout/CheckoutSteps";

export default function CartPage() {
  return (
    <main style={{ maxWidth: 640, margin: "0 auto", padding: 16, display: "grid", gap: 16 }}>
      <CheckoutSteps current={0} />
      <h1>Your bag</h1>
      <CartSummary editable />
      <Link href="/checkout" style={{ textAlign: "center", padding: 14, borderRadius: 6, background: "#1c1b19", color: "#fff", textDecoration: "none" }}>
        Checkout
      </Link>
    </main>
  );
}
