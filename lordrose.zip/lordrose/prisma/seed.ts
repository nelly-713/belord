import { PrismaClient } from "@prisma/client";

const prisma = new PrismaClient();

async function main() {
  const signature = await prisma.collection.upsert({
    where: { slug: "signature" },
    update: {},
    create: { slug: "signature", name: "Signature" },
  });

  await prisma.product.upsert({
    where: { slug: "classic-solitaire-ring" },
    update: {},
    create: {
      slug: "classic-solitaire-ring",
      name: "Classic Solitaire Ring",
      description: "A round brilliant set in a four-prong 14k gold setting.",
      category: "RING",
      collectionId: signature.id,
      engravable: true,
      variants: {
        create: ["5", "6", "7", "8"].map((size) => ({
          sku: `SOL-14YG-${size}`,
          metal: "14k Yellow Gold",
          size,
          gemstone: "Lab-grown diamond",
          caratWeight: "0.50",
          priceMinor: 125_000,
          stock: 3,
        })),
      },
    },
  });

  await prisma.product.upsert({
    where: { slug: "pearl-pendant" },
    update: {},
    create: {
      slug: "pearl-pendant",
      name: "Pearl Pendant",
      description: "A freshwater pearl on a fine sterling silver chain.",
      category: "PENDANT",
      collectionId: signature.id,
      variants: {
        create: [
          { sku: "PRL-SS-16", metal: "Sterling Silver", size: "16 in", gemstone: "Freshwater pearl", priceMinor: 18_000, stock: 10 },
          { sku: "PRL-SS-18", metal: "Sterling Silver", size: "18 in", gemstone: "Freshwater pearl", priceMinor: 19_500, stock: 10 },
        ],
      },
    },
  });
}

main()
  .then(() => console.log("Seeded: /products/classic-solitaire-ring and /products/pearl-pendant"))
  .finally(() => prisma.$disconnect());
