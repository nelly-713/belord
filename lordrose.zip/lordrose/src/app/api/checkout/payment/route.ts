import { NextResponse } from "next/server";
import { prisma } from "@/lib/db/prisma";
import { paymentSchema, type Address } from "@/lib/validation/checkout";
import { authorizeCardPayment, handleWorldpayResponse, paymentErrorResponse, type CheckoutStep } from "@/lib/payments";
import { buildDeviceData } from "@/lib/payments/device-data";

// Card-testing protection: cap attempts per order. Add IP rate limiting at your host/WAF too.
const MAX_ATTEMPTS = 5;

// POST { orderId, sessionHref, cardHolderName, browser } -> next checkout step
export async function POST(req: Request) {
  const parsed = paymentSchema.safeParse(await req.json().catch(() => null));
  if (!parsed.success) return NextResponse.json({ error: "Invalid payment request" }, { status: 400 });
  const { orderId, sessionHref, cardHolderName, browser } = parsed.data;

  const order = await prisma.order.findUnique({ where: { id: orderId }, include: { payments: true } });
  if (!order) return NextResponse.json({ error: "Order not found" }, { status: 404 });
  if (order.status !== "PENDING_PAYMENT") return NextResponse.json({ step: "authorized" } satisfies CheckoutStep);

  if (order.payments.length >= MAX_ATTEMPTS) {
    const body: CheckoutStep = { step: "refused", message: "Too many payment attempts for this order. Please contact us." };
    return NextResponse.json(body, { status: 429 });
  }

  // Any earlier attempt still mid-3DS is abandoned.
  await prisma.payment.updateMany({
    where: { orderId, status: { in: ["INITIATED", "AUTHENTICATING"] } },
    data: { status: "FAILED" },
  });

  const attempt = order.payments.length + 1;
  const payment = await prisma.payment.create({
    data: {
      orderId,
      attempt,
      transactionRef: `${order.number}-${attempt}`,
      amountMinor: order.totalMinor,
      currency: order.currency,
    },
  });

  const { name: _name, ...billing } = order.billingAddress as unknown as Address;

  try {
    const res = await authorizeCardPayment({
      transactionReference: payment.transactionRef,
      amountMinor: order.totalMinor,
      currency: order.currency,
      sessionHref,
      cardHolderName,
      email: order.email,
      billingAddress: billing,
      deviceData: buildDeviceData(req.headers.get("user-agent"), browser),
    });
    return NextResponse.json(await handleWorldpayResponse(payment.id, res));
  } catch (e) {
    return paymentErrorResponse(payment.id, e);
  }
}
