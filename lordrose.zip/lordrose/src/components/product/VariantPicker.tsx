"use client";
import Link from "next/link";
import { useState } from "react";
import { useCart } from "@/lib/cart/cart";
import { formatMoney } from "@/lib/money";

export interface PickerVariant {
  id: string;
  label: string;
  priceMinor: number;
  currency: string;
  stock: number;
}

export default function VariantPicker({ variants, engravable }: { variants: PickerVariant[]; engravable: boolean }) {
  const { add } = useCart();
  const firstInStock = variants.find((v) => v.stock > 0) ?? variants[0];
  const [selectedId, setSelectedId] = useState(firstInStock?.id);
  const [engraving, setEngraving] = useState("");
  const [added, setAdded] = useState(false);
  const [pops, setPops] = useState(0);
  const selected = variants.find((v) => v.id === selectedId);

  if (!selected) return <p>Currently unavailable.</p>;

  return (
    <div style={{ display: "grid", gap: 16 }}>
      <p style={{ fontSize: 22, margin: 0 }}>{formatMoney(selected.priceMinor, selected.currency)}</p>
      <fieldset style={{ border: 0, padding: 0, margin: 0, display: "flex", flexWrap: "wrap", gap: 8 }}>
        <legend style={{ marginBottom: 8 }}>Options</legend>
        {variants.map((v) => (
          <label key={v.id} style={{ border: `1px solid ${v.id === selectedId ? "#1c1b19" : "#c9c4bc"}`, borderRadius: 6, padding: "8px 12px", opacity: v.stock > 0 ? 1 : 0.5 }}>
            <input type="radio" name="variant" value={v.id} checked={v.id === selectedId} disabled={v.stock === 0}
              onChange={() => { setSelectedId(v.id); setAdded(false); }} style={{ marginRight: 6 }} />
            {v.label}{v.stock === 0 ? " — sold out" : ""}
          </label>
        ))}
      </fieldset>
      {engravable && (
        <label style={{ display: "grid", gap: 6, fontSize: 14 }}>
          Engraving (optional, up to 30 characters)
          <input value={engraving} onChange={(e) => setEngraving(e.target.value)} maxLength={30}
            style={{ height: 42, padding: "0 10px", border: "1px solid #c9c4bc", borderRadius: 6, fontSize: 16 }} />
        </label>
      )}
      <button type="button" disabled={selected.stock === 0}
        onClick={() => { add({ variantId: selected.id, quantity: 1, engraving: engraving.trim() || undefined }); setAdded(true); setPops((n) => n + 1); }}
        style={{ height: 48, border: 0, borderRadius: 6, background: "#1c1b19", color: "#fff", fontSize: 16 }}>
        {added ? <span key={pops} className="motion-pop">Added to bag ✓</span> : "Add to bag"}
      </button>
      {added && <p role="status" className="motion-fade-up" style={{ margin: 0 }}>Added. <Link href="/cart">View bag</Link></p>}
    </div>
  );
}
