import { NextResponse } from "next/server";
import { prisma } from "@/lib/db/prisma";
import { createOrderSchema } from "@/lib/validation/checkout";
import { priceCart, PricingError } from "@/lib/orders/pricing";
import { generateOrderNumber } from "@/lib/orders/order-number";

// POST: validate the bag, price it on the server, create the order (PENDING_PAYMENT).
export async function POST(req: Request) {
  const parsed = createOrderSchema.safeParse(await req.json().catch(() => null));
  if (!parsed.success) {
    return NextResponse.json({ error: "Please check your details.", issues: parsed.error.flatten() }, { status: 400 });
  }
  const { email, items, shippingAddress } = parsed.data;
  const billingAddress = parsed.data.billingAddress ?? shippingAddress;

  try {
    const quote = await priceCart(items);
    const order = await prisma.order.create({
      data: {
        number: generateOrderNumber(),
        email: email.toLowerCase(),
        subtotalMinor: quote.subtotalMinor,
        shippingMinor: quote.shippingMinor,
        taxMinor: quote.taxMinor,
        totalMinor: quote.totalMinor,
        currency: quote.currency,
        shippingAddress,
        billingAddress,
        items: {
          create: quote.lines.map((l) => ({
            variantId: l.variantId,
            quantity: l.quantity,
            unitPriceMinor: l.unitPriceMinor,
            engraving: l.engraving,
          })),
        },
      },
    });
    return NextResponse.json({ orderId: order.id });
  } catch (e) {
    if (e instanceof PricingError) return NextResponse.json({ error: e.message }, { status: 409 });
    throw e;
  }
}
