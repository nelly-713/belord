// Short, unambiguous, customer-facing order numbers, e.g. JW-7KQ2MX9A.
const ALPHABET = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789";

export function generateOrderNumber(prefix = "JW") {
  const bytes = crypto.getRandomValues(new Uint8Array(8));
  let s = "";
  for (const b of bytes) s += ALPHABET[b % ALPHABET.length]; // 256 is a multiple of 32: no bias
  return `${prefix}-${s}`;
}
