"use client";
import { useRouter } from "next/navigation";
import { useState } from "react";
import CartSummary from "@/components/cart/CartSummary";
import { useCart } from "@/lib/cart/cart";
import AddressForm, { emptyAddress, type AddressValue } from "./AddressForm";

export default function CheckoutDetailsForm() {
  const router = useRouter();
  const { items, ready } = useCart();
  const [email, setEmail] = useState("");
  const [shipping, setShipping] = useState<AddressValue>(emptyAddress);
  const [billing, setBilling] = useState<AddressValue>(emptyAddress);
  const [billingSame, setBillingSame] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [submitting, setSubmitting] = useState(false);

  async function onSubmit(e: React.FormEvent) {
    e.preventDefault();
    setError(null);
    setSubmitting(true);
    try {
      const res = await fetch("/api/checkout/session", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ email, items, shippingAddress: shipping, billingAddress: billingSame ? undefined : billing }),
      });
      const data = await res.json().catch(() => ({}));
      if (!res.ok || !data.orderId) {
        const fieldErrors = data.issues?.fieldErrors ? Object.values(data.issues.fieldErrors).flat().join(" ") : "";
        setError([data.error, fieldErrors].filter(Boolean).join(" ") || "Something went wrong. Please try again.");
        return;
      }
      router.push(`/checkout/payment?order=${encodeURIComponent(data.orderId)}`);
    } catch {
      setError("Network error. Please try again.");
    } finally {
      setSubmitting(false);
    }
  }

  if (ready && items.length === 0) return <CartSummary />;

  return (
    <div style={{ display: "grid", gap: 32, gridTemplateColumns: "repeat(auto-fit, minmax(300px, 1fr))", alignItems: "start" }}>
      <form onSubmit={onSubmit} style={{ display: "grid", gap: 20 }}>
        <label style={{ display: "grid", gap: 6, fontSize: 14 }}>
          Email
          <input type="email" value={email} onChange={(e) => setEmail(e.target.value)} autoComplete="email" required
            style={{ height: 42, padding: "0 10px", border: "1px solid #c9c4bc", borderRadius: 6, fontSize: 16 }} />
        </label>
        <AddressForm legend="Shipping address" value={shipping} onChange={setShipping} prefix="shipping" />
        <label style={{ display: "flex", gap: 8, alignItems: "center" }}>
          <input type="checkbox" checked={billingSame} onChange={(e) => setBillingSame(e.target.checked)} />
          Billing address is the same
        </label>
        {!billingSame && <AddressForm legend="Billing address" value={billing} onChange={setBilling} prefix="billing" />}
        {error && <p role="alert" style={{ color: "#b3261e", margin: 0 }}>{error}</p>}
        <button type="submit" disabled={submitting || !ready}
          style={{ height: 48, border: 0, borderRadius: 6, background: "#1c1b19", color: "#fff", fontSize: 16 }}>
          {submitting ? "Saving…" : "Continue to payment"}
        </button>
      </form>
      <aside>
        <h2 style={{ marginTop: 0 }}>Your bag</h2>
        <CartSummary />
      </aside>
    </div>
  );
}
