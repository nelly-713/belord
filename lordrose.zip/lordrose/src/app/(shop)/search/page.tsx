export default function Page() {
  return <main><h1>Search</h1>{/* TODO */}</main>;
}
