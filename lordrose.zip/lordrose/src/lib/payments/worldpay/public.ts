// Browser-safe Worldpay settings (NEXT_PUBLIC_* values are inlined at build time).
const isLive = process.env.NEXT_PUBLIC_WORLDPAY_ENV === "live";

export const CHECKOUT_ID = process.env.NEXT_PUBLIC_WORLDPAY_CHECKOUT_ID ?? "";

export const CHECKOUT_SDK_URL = isLive
  ? "https://access.worldpay.com/access-checkout/v2/checkout.js"
  : "https://try.access.worldpay.com/access-checkout/v2/checkout.js";

// Origin that posts the 3DS device-data-collection result back to the page.
export const CARDINAL_ORIGIN = isLive
  ? "https://centinelapi.cardinalcommerce.com"
  : "https://centinelapistag.cardinalcommerce.com";

export const CHALLENGE_COMPLETE_MESSAGE = "worldpay-3ds-challenge-complete";
