export default function RingSizeSelector() {
  return <div>{/* TODO: RingSizeSelector */}</div>;
}
