// Pure payment-state logic shared by the checkout flow and webhooks (no DB, easy to test).

export type PaymentStatusName =
  | "INITIATED"
  | "AUTHENTICATING"
  | "AUTHORIZED"
  | "SENT_FOR_SETTLEMENT"
  | "SETTLED"
  | "REFUSED"
  | "CANCELLED"
  | "REFUNDED"
  | "FAILED"
  | "CHARGED_BACK";

export type OrderStatusName =
  | "PENDING_PAYMENT"
  | "PAID"
  | "FULFILLING"
  | "SHIPPED"
  | "DELIVERED"
  | "CANCELLED"
  | "REFUNDED";

// What the browser is told to do next.
export type CheckoutStep =
  | { step: "authorized" }
  | { step: "deviceData"; ddc: { url: string; jwt: string; bin: string } }
  | { step: "challenge"; challenge: { url: string; jwt: string } }
  | { step: "refused"; message: string };

export function interpretOutcome(outcome: string | undefined): {
  status: PaymentStatusName;
  step: CheckoutStep["step"];
} {
  switch (outcome) {
    case "authorized":
      return { status: "AUTHORIZED", step: "authorized" };
    case "sentForSettlement":
      return { status: "SENT_FOR_SETTLEMENT", step: "authorized" };
    case "3dsDeviceDataRequired":
      return { status: "AUTHENTICATING", step: "deviceData" };
    case "3dsChallenged":
      return { status: "AUTHENTICATING", step: "challenge" };
    default:
      // refused, 3dsAuthenticationFailed, 3dsUnavailable, fraudHighRisk, sentForCancellation, unknown
      return { status: "REFUSED", step: "refused" };
  }
}

export function refusalMessage(outcome: string | undefined): string {
  switch (outcome) {
    case "3dsAuthenticationFailed":
      return "Your bank couldn't verify this payment. Please try again or use a different card.";
    case "3dsUnavailable":
      return "We couldn't reach your bank to verify this card. Please try again shortly or use a different card.";
    default:
      // Deliberately vague for fraud / refusals — don't tell card testers why.
      return "Your payment was declined. Please check your details or use a different card.";
  }
}

const EVENT_STATUS: Record<string, PaymentStatusName> = {
  authorized: "AUTHORIZED",
  sentForSettlement: "SENT_FOR_SETTLEMENT",
  settled: "SETTLED",
  refused: "REFUSED",
  cancelled: "CANCELLED",
  cancelledByCustomer: "CANCELLED",
  expired: "CANCELLED",
  requestExpired: "CANCELLED",
  settlementFailed: "FAILED",
  settlementRejected: "FAILED",
  error: "FAILED",
  refunded: "REFUNDED",
  chargedBack: "CHARGED_BACK",
};

// Events like sentForAuthorization, sentForRefund, refundFailed, tokenCreated are logged only.
export function statusForEvent(type: string): PaymentStatusName | null {
  return EVENT_STATUS[type] ?? null;
}

const RANK: Record<PaymentStatusName, number> = {
  INITIATED: 0,
  FAILED: 1,
  AUTHENTICATING: 1,
  REFUSED: 2,
  AUTHORIZED: 2,
  SENT_FOR_SETTLEMENT: 3,
  CANCELLED: 3,
  SETTLED: 4,
  REFUNDED: 5,
  CHARGED_BACK: 6,
};

// Webhooks can arrive late, twice, or out of order. Never move a payment backwards,
// except that a failure can land on anything not yet settled.
export function shouldApply(current: PaymentStatusName, next: PaymentStatusName): boolean {
  if (next === "FAILED") return RANK[current] < RANK.SETTLED;
  return RANK[next] >= RANK[current];
}

export function orderStatusFor(payment: PaymentStatusName, order: OrderStatusName): OrderStatusName | null {
  switch (payment) {
    case "AUTHORIZED":
    case "SENT_FOR_SETTLEMENT":
    case "SETTLED":
      return order === "PENDING_PAYMENT" ? "PAID" : null;
    case "REFUNDED":
      return "REFUNDED";
    case "CANCELLED":
      return order === "PENDING_PAYMENT" || order === "PAID" ? "CANCELLED" : null;
    default:
      return null; // REFUSED/FAILED leave the order open so the customer can retry
  }
}
