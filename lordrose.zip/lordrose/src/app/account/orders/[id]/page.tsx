export default function Page() {
  return <main><h1>Order Details</h1>{/* TODO */}</main>;
}
