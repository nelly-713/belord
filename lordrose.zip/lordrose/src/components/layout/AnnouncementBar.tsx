export default function AnnouncementBar() {
  return <div>{/* TODO: AnnouncementBar */}</div>;
}
