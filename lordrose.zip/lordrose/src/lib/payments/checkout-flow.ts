import "server-only";
import { NextResponse } from "next/server";
import { applyPaymentStatus } from "@/lib/orders/orders";
import { interpretOutcome, refusalMessage, type CheckoutStep } from "./status";
import { WorldpayError } from "./worldpay/client";
import type { WorldpayResponse } from "./worldpay/types";

// Record a Worldpay response and tell the browser what to do next.
export async function handleWorldpayResponse(paymentId: string, res: WorldpayResponse): Promise<CheckoutStep> {
  const { status, step } = interpretOutcome(res.outcome);
  await applyPaymentStatus(paymentId, status, {
    worldpayPaymentId: res.paymentId,
    actions: res._actions,
    raw: res,
  });

  if (step === "authorized") return { step };
  if (step === "deviceData" && res.deviceDataCollection) {
    const { url, jwt, bin } = res.deviceDataCollection;
    return { step, ddc: { url, jwt, bin } };
  }
  if (step === "challenge" && res.challenge) {
    return { step, challenge: { url: res.challenge.url, jwt: res.challenge.jwt } };
  }
  if (step !== "refused") console.error("Worldpay response missing 3DS data", res.outcome);
  return { step: "refused", message: refusalMessage(res.outcome) };
}

// A 4xx from Worldpay means the request was rejected, so the attempt failed.
// Timeouts and 5xx are unknown — leave the status alone and let webhooks settle it.
export async function paymentErrorResponse(paymentId: string, error: unknown) {
  if (error instanceof WorldpayError) {
    console.error("Worldpay error", error.status, error.detail);
    if (error.status < 500) await applyPaymentStatus(paymentId, "FAILED", {});
  } else {
    console.error("Payment request failed", error);
  }
  const body: CheckoutStep = {
    step: "refused",
    message: "We couldn't process your payment. Please try again or use a different card.",
  };
  return NextResponse.json(body, { status: 502 });
}
