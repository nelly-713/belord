export default function Spinner() {
  return <span className="motion-spinner" aria-hidden="true" />;
}
