export default function Page() {
  return <main><h1>Jewelry Care</h1>{/* TODO */}</main>;
}
