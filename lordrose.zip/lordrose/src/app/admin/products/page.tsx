export default function Page() {
  return <main><h1>Products</h1>{/* TODO */}</main>;
}
