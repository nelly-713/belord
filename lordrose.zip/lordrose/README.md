# Lord Rose — lordrose.com

Online jewelry store: boutique, product pages, bag, checkout with Worldpay (card fields, 3D Secure,
payment status updates), homepage and About page. Runs on Cloudflare Workers with a Neon Postgres database.

## First time: put it on GitHub

```
bash scripts/push-to-github.sh
```

Installs packages, creates the first database migration, and pushes to a new **private** repository
called `lordrose` (pass another name as the first argument). If the GitHub command-line tool (`gh`)
is installed and logged in, the repository is created for you; otherwise the script asks you to create an
empty one at github.com/new and paste its URL.

To push later changes, run the same command again.

## First deploy to lordrose.com

Follow the steps at the top of `scripts/deploy-cloudflare.sh` (add the domain to Cloudflare, point
IONOS name servers at Cloudflare, Workers Paid plan, Neon project), then:

```
bash scripts/deploy-cloudflare.sh
```

## Automatic deploys (every push to GitHub updates the site)

In Cloudflare: **Workers & Pages → lordrose → Settings → Build → Connect** your GitHub repository, then set:

| Setting | Value |
|---|---|
| Build command | `npm run cf-build` |
| Deploy command | `npx opennextjs-cloudflare deploy` |
| Production branch | `main` |

Under **Build variables and secrets** add:

| Name | Value | Type |
|---|---|---|
| `NEXT_PUBLIC_SITE_URL` | `https://lordrose.com` | Variable |
| `NEXT_PUBLIC_WORLDPAY_ENV` | `try` (later `live`) | Variable |
| `NEXT_PUBLIC_WORLDPAY_CHECKOUT_ID` | from the Worldpay Dashboard | Variable |
| `DATABASE_URL` | Neon pooled connection string | Secret |
| `DATABASE_URL_UNPOOLED` | Neon direct connection string | Secret |

The build applies any new database changes (`prisma migrate deploy`) before building.
Worldpay passwords and the database connection used by the live site are stored on the Worker by
`deploy-cloudflare.sh`; they never go to GitHub.

## Working on it locally

```
cp .env.example .env        # fill in a local Postgres URL and Worldpay Try credentials
npm install
npx prisma migrate dev
npx prisma db seed          # two sample products
npm run dev                 # http://localhost:3000
```

## Where things are

| What | Where |
|---|---|
| All brand wording (tagline, About story, email) | `src/content/brand.ts` — lines marked `REPLACE` are placeholders |
| Colors and fonts | `src/styles/brand.css` |
| Checkout animations | `src/styles/motion.css` |
| Homepage / About / Shop | `src/app/page.tsx`, `src/app/(content)/about/page.tsx`, `src/app/(shop)/shop/page.tsx` |
| Worldpay integration | `src/lib/payments/` — details in `docs/WORLDPAY.md` |
| Shipping rates | `src/lib/shipping/rates.ts` |
| Policy pages (to fill in) | `src/app/(content)/shipping-returns`, `faq`, `care-guide`, `ring-size-guide`, `contact` |

## Going live with real payments

1. Generate **Live** credentials in the Worldpay Dashboard (Developer Tools → API credentials).
2. Change `try` to `live` in `wrangler.jsonc` (`WORLDPAY_ENV`, `NEXT_PUBLIC_WORLDPAY_ENV`) and in the Cloudflare
   build variable `NEXT_PUBLIC_WORLDPAY_ENV`; update the live checkout ID.
3. Store the live Worldpay username/password/entity as Worker secrets (`npx wrangler secret put WORLDPAY_API_USERNAME`, etc.).
4. Add the Live webhook in the Worldpay Dashboard: `https://lordrose.com/api/webhooks/worldpay`.
5. Push.
