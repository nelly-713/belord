export default function Page() {
  return <main><h1>Wishlist</h1>{/* TODO */}</main>;
}
