import "server-only";
import { followAction, worldpayPost } from "./client";
import { worldpayConfig } from "./config";
import type { BrowserDeviceData, WorldpayActions, WorldpayBillingAddress, WorldpayResponse } from "./types";

// Authorize (not settle) a card payment from a Checkout SDK session.
// Settlement happens when the order ships — see settleOrder() in lib/orders/orders.ts.
export function authorizeCardPayment(args: {
  transactionReference: string;
  amountMinor: number;
  currency: string;
  sessionHref: string;
  cardHolderName: string;
  email: string;
  billingAddress: WorldpayBillingAddress;
  deviceData: BrowserDeviceData;
}): Promise<WorldpayResponse> {
  return worldpayPost("/api/payments", {
    transactionReference: args.transactionReference,
    merchant: { entity: worldpayConfig.entity },
    instruction: {
      method: "card",
      paymentInstrument: {
        type: "checkout",
        sessionHref: args.sessionHref,
        cardHolderName: args.cardHolderName,
        billingAddress: args.billingAddress,
      },
      narrative: { line1: worldpayConfig.narrative },
      value: { currency: args.currency, amount: args.amountMinor },
      customer: { email: args.email },
      settlement: { auto: false },
      threeDS: {
        type: "integrated",
        mode: "always",
        challenge: {
          returnUrl: `${worldpayConfig.siteUrl}/api/checkout/3ds/return`,
          windowSize: "390x400",
        },
        deviceData: args.deviceData,
      },
    },
  });
}

export function supplyDeviceData(actions: WorldpayActions, collectionReference?: string) {
  return followAction(actions.supply3dsDeviceData, collectionReference ? { collectionReference } : {});
}

export function completeChallenge(actions: WorldpayActions) {
  return followAction(actions.complete3dsChallenge, {});
}

export function settlePayment(actions: WorldpayActions) {
  return followAction(actions.settlePayment, {});
}

export function cancelPayment(actions: WorldpayActions) {
  return followAction(actions.cancelPayment, {});
}

export function refundPayment(actions: WorldpayActions) {
  return followAction(actions.refundPayment, {});
}

export function partiallyRefundPayment(actions: WorldpayActions, amountMinor: number, currency: string, reference: string) {
  return followAction(actions.partiallyRefundPayment, { reference, value: { amount: amountMinor, currency } });
}
