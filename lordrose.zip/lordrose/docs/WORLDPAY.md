# Worldpay integration

## Setup
1. Fill in `.env` from `.env.example`. `WORLDPAY_ENV` and `NEXT_PUBLIC_WORLDPAY_ENV` must match (`try` for sandbox).
2. `npm install && npx prisma migrate dev --name worldpay-checkout && npx prisma db seed`
3. `npm run dev`, open http://localhost:3000/products/classic-solitaire-ring, add to bag, check out.
4. Use Worldpay's sandbox test cards (see their "Testing" docs) to try authorized, refused and 3DS challenge cases.
5. To receive webhooks locally, expose the dev server with a tunnel and register
   `https://<tunnel>/api/webhooks/worldpay` with Worldpay. Set `NEXT_PUBLIC_SITE_URL` to the tunnel URL
   too — the 3DS challenge return URL is built from it.

## Flow
- `/checkout` → `POST /api/checkout/session` — order created with server-side prices (PENDING_PAYMENT).
- `/checkout/payment` → Worldpay Checkout SDK fields → encrypted session (valid 1 minute, single use).
- `POST /api/checkout/payment` → Payments API authorization with 3DS (`mode: always`), auto-settle off.
- `3dsDeviceDataRequired` → hidden device-data iframe → `POST /api/checkout/3ds {step: "deviceData"}`.
- `3dsChallenged` → challenge iframe → bank posts to `/api/checkout/3ds/return` → `POST /api/checkout/3ds {step: "challenge"}`.
- `authorized` → order PAID, stock decremented once → `/checkout/confirmation`.
- Webhooks (`/api/webhooks/worldpay`) are the source of truth for settled / refunded / cancelled / chargebacks.

## After the sale
- `settleOrder(orderId)` — capture when the order ships. Authorizations expire, so settle promptly.
- `cancelOrderPayment(orderId)` — release an authorization if an unshipped order is cancelled.
- `refundOrder(orderId)` — full refund after settlement.
These are server functions in `src/lib/orders/orders.ts`; call them from your admin once it has authentication.

## Before going live
- Ask your Implementation Manager to enable webhook signing; set `WORLDPAY_WEBHOOK_SECRET` and `WORLDPAY_WEBHOOK_KEY_ID`,
  and confirm the signature encoding (the verifier accepts hex or base64).
- Switch both env flags to `live` and use your live credentials, entity and checkout ID.
- Add authentication to `/admin` and IP rate limiting on `/api/checkout/*`.
- Replace the placeholder shipping rates and add tax calculation (`src/lib/orders/pricing.ts`).
