import Link from "next/link";
import { formatMoney } from "@/lib/money";
import { CATEGORY_LABELS } from "@/content/brand";

export interface CardProduct {
  slug: string;
  name: string;
  category: string;
  fromPriceMinor?: number;
  currency?: string;
  image?: { url: string; alt: string };
}

export default function ProductCard({ product }: { product: CardProduct }) {
  return (
    <Link href={`/products/${product.slug}`} className="lr-card">
      <div className="lr-card__img">
        {product.image ? (
          // eslint-disable-next-line @next/next/no-img-element
          <img src={product.image.url} alt={product.image.alt} loading="lazy" />
        ) : (
          <span>Photo coming soon</span>
        )}
      </div>
      <span className="lr-card__cat">{CATEGORY_LABELS[product.category] ?? product.category}</span>
      <span className="lr-card__name">{product.name}</span>
      {product.fromPriceMinor !== undefined && product.currency && (
        <span className="lr-card__price">{formatMoney(product.fromPriceMinor, product.currency)}</span>
      )}
    </Link>
  );
}
