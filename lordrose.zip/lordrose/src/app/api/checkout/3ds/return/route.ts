import { CHALLENGE_COMPLETE_MESSAGE } from "@/lib/payments/worldpay/public";

// The bank's challenge page POSTs here (inside the challenge iframe) when the customer finishes.
// We just tell the parent checkout page, which then calls complete3dsChallenge.
export async function POST() {
  const html = `<!doctype html><html><body><script>
window.parent.postMessage({ type: ${JSON.stringify(CHALLENGE_COMPLETE_MESSAGE)} }, window.location.origin);
</script></body></html>`;
  return new Response(html, {
    headers: { "Content-Type": "text/html; charset=utf-8", "Cache-Control": "no-store" },
  });
}
