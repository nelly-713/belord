import { z } from "zod";

// Limits match Worldpay's billingAddress rules.
export const addressSchema = z
  .object({
    name: z.string().trim().min(1, "Name is required").max(255),
    address1: z.string().trim().min(1, "Address is required").max(80),
    address2: z.string().trim().max(80).optional().transform((v) => v || undefined),
    city: z.string().trim().min(1, "City is required").max(50),
    state: z.string().trim().max(30).optional().transform((v) => v || undefined),
    postalCode: z.string().trim().max(15).optional().transform((v) => v || undefined),
    countryCode: z.string().trim().length(2).transform((v) => v.toUpperCase()),
  })
  .refine((a) => a.countryCode === "IE" || !!a.postalCode, {
    message: "Postal code is required",
    path: ["postalCode"],
  });

export type Address = z.infer<typeof addressSchema>;

export const cartItemSchema = z.object({
  variantId: z.string().min(1),
  quantity: z.number().int().min(1).max(10),
  engraving: z.string().trim().max(30).optional(),
});

export const cartSchema = z.object({ items: z.array(cartItemSchema).max(50) });

export const createOrderSchema = z.object({
  email: z.string().trim().email().max(128),
  items: z.array(cartItemSchema).min(1).max(50),
  shippingAddress: addressSchema,
  billingAddress: addressSchema.optional(),
});

export const paymentSchema = z.object({
  orderId: z.string().min(1),
  sessionHref: z.string().url(),
  cardHolderName: z.string().trim().min(1).max(255),
  browser: z
    .object({
      acceptHeader: z.string().max(2048).optional(),
      language: z.string().max(35).optional(),
      screenHeight: z.number().int().nonnegative().optional(),
      screenWidth: z.number().int().nonnegative().optional(),
      colorDepth: z.number().int().nonnegative().optional(),
      timeZoneOffset: z.number().int().min(-1440).max(1440).optional(),
      javaEnabled: z.boolean().optional(),
    })
    .default({}),
});

export const threeDSSchema = z.discriminatedUnion("step", [
  z.object({
    step: z.literal("deviceData"),
    orderId: z.string().min(1),
    collectionReference: z.string().max(200).optional(),
  }),
  z.object({ step: z.literal("challenge"), orderId: z.string().min(1) }),
]);
