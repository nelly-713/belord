import { notFound } from "next/navigation";
import { prisma } from "@/lib/db/prisma";
import VariantPicker from "@/components/product/VariantPicker";

export const dynamic = "force-dynamic";

export default async function ProductPage({ params }: { params: Promise<{ slug: string }> }) {
  const { slug } = await params;
  const product = await prisma.product.findUnique({
    where: { slug },
    include: { variants: { orderBy: { priceMinor: "asc" } }, images: { orderBy: { position: "asc" } } },
  });
  if (!product) notFound();

  const variants = product.variants.map((v) => ({
    id: v.id,
    label: [v.metal, v.size && `Size ${v.size}`].filter(Boolean).join(" · "),
    priceMinor: v.priceMinor,
    currency: v.currency,
    stock: v.stock,
  }));

  return (
    <main style={{ maxWidth: 1000, margin: "0 auto", padding: 16, display: "grid", gap: 24, gridTemplateColumns: "repeat(auto-fit, minmax(300px, 1fr))" }}>
      <div>
        {product.images[0] ? (
          // eslint-disable-next-line @next/next/no-img-element
          <img src={product.images[0].url} alt={product.images[0].alt} style={{ width: "100%", borderRadius: 8 }} />
        ) : (
          <div style={{ aspectRatio: "1", background: "#f2eee7", borderRadius: 8 }} />
        )}
      </div>
      <div style={{ display: "grid", gap: 12, alignContent: "start" }}>
        <h1 style={{ margin: 0 }}>{product.name}</h1>
        <p>{product.description}</p>
        {product.certificate && <p style={{ fontSize: 14, color: "#6b665e" }}>Certificate: {product.certificate}</p>}
        <VariantPicker variants={variants} engravable={product.engravable} />
      </div>
    </main>
  );
}
