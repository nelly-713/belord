export default function ProductGallery() {
  return <div>{/* TODO: ProductGallery */}</div>;
}
