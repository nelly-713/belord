"use client";

export interface AddressValue {
  name: string;
  address1: string;
  address2: string;
  city: string;
  state: string;
  postalCode: string;
  countryCode: string;
}

export const emptyAddress: AddressValue = {
  name: "",
  address1: "",
  address2: "",
  city: "",
  state: "",
  postalCode: "",
  countryCode: "US",
};

// Extend this list to the countries you ship to.
const COUNTRIES = [
  ["US", "United States"],
  ["CA", "Canada"],
  ["GB", "United Kingdom"],
  ["IE", "Ireland"],
  ["AU", "Australia"],
] as const;

const field = { display: "grid", gap: 6, fontSize: 14 } as const;
const input = { height: 42, padding: "0 10px", border: "1px solid #c9c4bc", borderRadius: 6, fontSize: 16 } as const;

export default function AddressForm({
  legend,
  value,
  onChange,
  prefix,
}: {
  legend: string;
  value: AddressValue;
  onChange: (v: AddressValue) => void;
  prefix: string;
}) {
  const set = (k: keyof AddressValue) => (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement>) =>
    onChange({ ...value, [k]: e.target.value });
  const ac = (token: string) => `section-${prefix} ${token}`;

  return (
    <fieldset style={{ border: 0, padding: 0, margin: 0, display: "grid", gap: 12 }}>
      <legend style={{ fontWeight: 600, marginBottom: 8 }}>{legend}</legend>
      <label style={field}>Full name<input style={input} value={value.name} onChange={set("name")} autoComplete={ac("name")} required maxLength={255} /></label>
      <label style={field}>Address<input style={input} value={value.address1} onChange={set("address1")} autoComplete={ac("address-line1")} required maxLength={80} /></label>
      <label style={field}>Apartment, suite (optional)<input style={input} value={value.address2} onChange={set("address2")} autoComplete={ac("address-line2")} maxLength={80} /></label>
      <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 12 }}>
        <label style={field}>City<input style={input} value={value.city} onChange={set("city")} autoComplete={ac("address-level2")} required maxLength={50} /></label>
        <label style={field}>State / region<input style={input} value={value.state} onChange={set("state")} autoComplete={ac("address-level1")} maxLength={30} /></label>
      </div>
      <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 12 }}>
        <label style={field}>Postal code<input style={input} value={value.postalCode} onChange={set("postalCode")} autoComplete={ac("postal-code")} maxLength={15} /></label>
        <label style={field}>
          Country
          <select style={input} value={value.countryCode} onChange={set("countryCode")} autoComplete={ac("country")}>
            {COUNTRIES.map(([code, label]) => (
              <option key={code} value={code}>{label}</option>
            ))}
          </select>
        </label>
      </div>
    </fieldset>
  );
}
