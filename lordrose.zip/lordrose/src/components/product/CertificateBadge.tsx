export default function CertificateBadge() {
  return <div>{/* TODO: CertificateBadge */}</div>;
}
