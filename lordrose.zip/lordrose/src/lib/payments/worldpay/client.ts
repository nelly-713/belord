import "server-only";
import { worldpayConfig } from "./config";
import type { WorldpayAction, WorldpayResponse } from "./types";

export class WorldpayError extends Error {
  constructor(public status: number, public detail: string) {
    super(`Worldpay request failed (${status})`);
    this.name = "WorldpayError";
  }
}

export function authHeader() {
  const raw = `${worldpayConfig.username}:${worldpayConfig.password}`;
  return `Basic ${Buffer.from(raw).toString("base64")}`;
}

async function send(url: string, method: string, body?: unknown): Promise<WorldpayResponse> {
  const res = await fetch(url, {
    method,
    headers: {
      Authorization: authHeader(),
      "Content-Type": "application/json",
      Accept: "application/json",
      "WP-Api-Version": worldpayConfig.apiVersion,
    },
    body: body === undefined ? undefined : JSON.stringify(body),
    cache: "no-store",
    signal: AbortSignal.timeout(30_000),
  });
  const text = await res.text();
  if (!res.ok) throw new WorldpayError(res.status, text);
  return text ? (JSON.parse(text) as WorldpayResponse) : {};
}

export function worldpayPost(path: string, body?: unknown) {
  return send(`${worldpayConfig.baseUrl}${path}`, "POST", body);
}

// Follow an action link from a previous response (settle, refund, 3DS steps...).
// Only Worldpay's own host is allowed, so a bad stored href can't redirect our credentials.
export function followAction(action: WorldpayAction | undefined, body?: unknown) {
  if (!action?.href) throw new Error("That Worldpay action is not available for this payment");
  const url = new URL(action.href);
  if (url.origin !== new URL(worldpayConfig.baseUrl).origin) {
    throw new Error(`Refusing to call non-Worldpay host ${url.origin}`);
  }
  return send(url.toString(), action.method ?? "POST", body);
}
