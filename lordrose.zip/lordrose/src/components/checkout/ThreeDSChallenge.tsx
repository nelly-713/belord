"use client";
import { useEffect, useRef } from "react";
import { CARDINAL_ORIGIN, CHALLENGE_COMPLETE_MESSAGE } from "@/lib/payments/worldpay/public";

const esc = (s: string) =>
  s.replace(/&/g, "&amp;").replace(/"/g, "&quot;").replace(/</g, "&lt;").replace(/>/g, "&gt;");

// A tiny document that auto-POSTs a form — keeps the 3DS JWT out of URLs and server logs.
function autoPostDocument(action: string, fields: Record<string, string>) {
  const inputs = Object.entries(fields)
    .map(([k, v]) => `<input type="hidden" name="${esc(k)}" value="${esc(v)}">`)
    .join("");
  return `<!doctype html><html><body><form id="f" method="POST" action="${esc(action)}">${inputs}</form><script>document.getElementById("f").submit();<\/script></body></html>`;
}

// Step 1: hidden device data collection. Resolves with a collectionReference (or none on timeout).
export function DeviceDataCollector({
  ddc,
  onDone,
}: {
  ddc: { url: string; jwt: string; bin: string };
  onDone: (collectionReference?: string) => void;
}) {
  const done = useRef(false);

  useEffect(() => {
    done.current = false;
    function finish(ref?: string) {
      if (done.current) return;
      done.current = true;
      onDone(ref);
    }
    function onMessage(e: MessageEvent) {
      if (e.origin !== CARDINAL_ORIGIN) return;
      let data: unknown = e.data;
      if (typeof data === "string") {
        try {
          data = JSON.parse(data);
        } catch {
          return;
        }
      }
      const msg = data as { MessageType?: string; SessionId?: string; Status?: boolean };
      if (msg?.MessageType === "profile.completed") finish(msg.Status && msg.SessionId ? String(msg.SessionId) : undefined);
    }
    window.addEventListener("message", onMessage);
    const timer = window.setTimeout(() => finish(undefined), 10_000);
    return () => {
      window.removeEventListener("message", onMessage);
      window.clearTimeout(timer);
    };
  }, [onDone]);

  return (
    <iframe
      title="Card verification"
      aria-hidden="true"
      srcDoc={autoPostDocument(ddc.url, { Bin: ddc.bin, JWT: ddc.jwt })}
      width={1}
      height={1}
      style={{ display: "none" }}
    />
  );
}

// Step 2 (only if the bank asks): the visible challenge, e.g. a one-time passcode.
export function ChallengeFrame({ challenge, onDone }: { challenge: { url: string; jwt: string }; onDone: () => void }) {
  useEffect(() => {
    function onMessage(e: MessageEvent) {
      if (e.origin !== window.location.origin) return;
      if ((e.data as { type?: string })?.type === CHALLENGE_COMPLETE_MESSAGE) onDone();
    }
    window.addEventListener("message", onMessage);
    return () => window.removeEventListener("message", onMessage);
  }, [onDone]);

  return (
    <div
      role="dialog"
      className="motion-fade-in"
      aria-modal="true"
      aria-label="Verify your card"
      style={{ position: "fixed", inset: 0, background: "rgba(0,0,0,.55)", display: "grid", placeItems: "center", zIndex: 1000, padding: 16 }}
    >
      <div className="motion-scale-in" style={{ background: "#fff", borderRadius: 8, padding: 16, maxWidth: "100%" }}>
        <p style={{ margin: "0 0 12px" }}>Your bank needs to confirm this payment.</p>
        <iframe
          title="Bank verification"
          srcDoc={autoPostDocument(challenge.url, { JWT: challenge.jwt })}
          width={390}
          height={400}
          style={{ border: 0, maxWidth: "100%", display: "block" }}
        />
      </div>
    </div>
  );
}
