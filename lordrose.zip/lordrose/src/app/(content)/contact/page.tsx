export default function Page() {
  return <main><h1>Contact</h1>{/* TODO */}</main>;
}
