export default function Page() {
  return <main><h1>Certifications & Sourcing</h1>{/* TODO */}</main>;
}
