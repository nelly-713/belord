// Placeholder rules — replace with your carrier's rates.
// Fine jewelry should ship insured with signature on delivery.
export const FREE_SHIPPING_THRESHOLD_MINOR = 50_000; // $500
export const INSURED_SHIPPING_MINOR = 2_500; // $25

export function shippingFor(subtotalMinor: number) {
  return subtotalMinor >= FREE_SHIPPING_THRESHOLD_MINOR ? 0 : INSURED_SHIPPING_MINOR;
}
