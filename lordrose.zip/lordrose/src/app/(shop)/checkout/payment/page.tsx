import { headers } from "next/headers";
import { notFound, redirect } from "next/navigation";
import { prisma } from "@/lib/db/prisma";
import { formatMoney } from "@/lib/money";
import WorldpayCardForm from "@/components/checkout/WorldpayCardForm";
import CheckoutSteps from "@/components/checkout/CheckoutSteps";

export const dynamic = "force-dynamic";

export default async function PaymentPage({ searchParams }: { searchParams: Promise<{ order?: string }> }) {
  const { order: orderId } = await searchParams;
  if (!orderId) notFound();

  const order = await prisma.order.findUnique({
    where: { id: orderId },
    include: { items: { include: { variant: { include: { product: true } } } } },
  });
  if (!order) notFound();
  if (order.status !== "PENDING_PAYMENT") redirect(`/checkout/confirmation?order=${order.id}`);

  // The real browser Accept header, used for 3DS device data.
  const acceptHeader = (await headers()).get("accept") ?? "";
  const total = formatMoney(order.totalMinor, order.currency);

  return (
    <main style={{ maxWidth: 1000, margin: "0 auto", padding: 16, display: "grid", gap: 32, gridTemplateColumns: "repeat(auto-fit, minmax(300px, 1fr))", alignItems: "start" }}>
      <section>
        <CheckoutSteps current={2} />
        <h1 style={{ marginTop: 0 }}>Payment</h1>
        <WorldpayCardForm orderId={order.id} amountLabel={total} acceptHeader={acceptHeader} />
      </section>
      <aside>
        <h2 style={{ marginTop: 0 }}>Order {order.number}</h2>
        {order.items.map((item) => (
          <div key={item.id} style={{ display: "flex", justifyContent: "space-between", gap: 12, marginBottom: 8 }}>
            <span>
              {item.variant.product.name} × {item.quantity}
              {item.engraving && <span style={{ display: "block", fontSize: 13 }}>Engraving: “{item.engraving}”</span>}
            </span>
            <span>{formatMoney(item.unitPriceMinor * item.quantity, order.currency)}</span>
          </div>
        ))}
        <p style={{ display: "flex", justifyContent: "space-between", borderTop: "1px solid #e6e1d8", paddingTop: 12, fontWeight: 600 }}>
          <span>Total</span><span>{total}</span>
        </p>
      </aside>
    </main>
  );
}
