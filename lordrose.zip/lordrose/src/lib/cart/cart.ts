"use client";
import { useCallback, useEffect, useState } from "react";
import type { CartItem } from "./types";

// Browser-side bag kept in localStorage. Prices are always recalculated on the server.
const KEY = "jewelry-cart-v1";
const CHANGED = "cart:changed";

function read(): CartItem[] {
  try {
    const parsed = JSON.parse(localStorage.getItem(KEY) ?? "[]");
    return Array.isArray(parsed) ? parsed : [];
  } catch {
    return [];
  }
}

function write(items: CartItem[]) {
  try {
    localStorage.setItem(KEY, JSON.stringify(items));
  } catch {
    // storage unavailable (private mode) — the bag just won't persist
  }
  window.dispatchEvent(new Event(CHANGED));
}

const sameLine = (a: CartItem, b: CartItem) =>
  a.variantId === b.variantId && (a.engraving ?? "") === (b.engraving ?? "");

export function useCart() {
  const [items, setItems] = useState<CartItem[]>([]);
  const [ready, setReady] = useState(false);

  useEffect(() => {
    const sync = () => setItems(read());
    sync();
    setReady(true);
    window.addEventListener(CHANGED, sync);
    window.addEventListener("storage", sync);
    return () => {
      window.removeEventListener(CHANGED, sync);
      window.removeEventListener("storage", sync);
    };
  }, []);

  const add = useCallback((item: CartItem) => {
    const current = read();
    const existing = current.find((i) => sameLine(i, item));
    if (existing) existing.quantity = Math.min(10, existing.quantity + item.quantity);
    else current.push(item);
    write(current);
  }, []);

  const setQuantity = useCallback((item: CartItem, quantity: number) => {
    write(read().map((i) => (sameLine(i, item) ? { ...i, quantity } : i)).filter((i) => i.quantity > 0));
  }, []);

  const remove = useCallback((item: CartItem) => setQuantity(item, 0), [setQuantity]);
  const clear = useCallback(() => write([]), []);

  return { items, ready, add, setQuantity, remove, clear, count: items.reduce((n, i) => n + i.quantity, 0) };
}
