export default function Page() {
  return <main><h1>Ring Size Guide</h1>{/* TODO */}</main>;
}
