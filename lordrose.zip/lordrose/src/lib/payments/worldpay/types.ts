export type WorldpayOutcome =
  | "authorized"
  | "sentForSettlement"
  | "refused"
  | "3dsDeviceDataRequired"
  | "3dsChallenged"
  | "3dsAuthenticationFailed"
  | "3dsUnavailable"
  | "fraudHighRisk"
  | "sentForCancellation"
  | "sentForRefund"
  | "sentForPartialRefund";

export interface WorldpayAction {
  href: string;
  method?: string;
}

export type WorldpayActionName =
  | "settlePayment"
  | "partiallySettlePayment"
  | "cancelPayment"
  | "partiallyCancelPayment"
  | "reversePayment"
  | "refundPayment"
  | "partiallyRefundPayment"
  | "supply3dsDeviceData"
  | "complete3dsChallenge";

export type WorldpayActions = Partial<Record<WorldpayActionName, WorldpayAction>>;

export interface WorldpayResponse {
  outcome?: WorldpayOutcome | string;
  paymentId?: string;
  transactionReference?: string;
  deviceDataCollection?: { jwt: string; url: string; bin: string };
  challenge?: { reference: string; url: string; jwt: string; payload?: string };
  _actions?: WorldpayActions;
  [key: string]: unknown;
}

export interface BrowserDeviceData {
  channel: "browser";
  acceptHeader: string;
  userAgentHeader: string;
  browserLanguage?: string;
  browserScreenHeight?: number;
  browserScreenWidth?: number;
  browserColorDepth?: number;
  browserJavaEnabled?: boolean;
  browserJavascriptEnabled?: boolean;
  timeZone?: string;
}

export interface WorldpayBillingAddress {
  address1: string;
  address2?: string;
  city: string;
  state?: string;
  postalCode?: string;
  countryCode: string;
}
