import type { PaymentStatusName } from "./status";

export interface HistoryEvent {
  eventName: string;
  type?: string;
  value?: { amount: number };
}

const has = (events: HistoryEvent[], ...names: string[]) => events.some((e) => names.includes(e.eventName));

// Work out a payment's status from Worldpay's event history (Payment Queries API).
export function statusFromPaymentHistory(events: HistoryEvent[], amountMinor: number): PaymentStatusName | null {
  const settled = has(events, "settlementRequested", "settlementRequestSubmitted", "saleSucceeded");

  if (has(events, "refundRequested", "refundRequestSubmitted")) {
    let refunded = 0;
    let full = false;
    for (const e of events) {
      if (e.eventName !== "refundRequested") continue;
      if (e.type === "partialRefund" && e.value) refunded += e.value.amount;
      else full = true;
    }
    if (full || refunded >= amountMinor) return "REFUNDED";
    // partial refund: the order stays as it is
  }
  if (has(events, "reversalRequested", "reversalRequestSubmitted")) return settled ? "REFUNDED" : "CANCELLED";
  if (has(events, "cancellationRequested", "cancellationRequestSubmitted")) return "CANCELLED";
  if (settled) return "SENT_FOR_SETTLEMENT";
  if (has(events, "authorizationSucceeded")) return "AUTHORIZED";
  if (has(events, "authorizationRefused", "saleRefused")) return "REFUSED";
  if (has(events, "authorizationFailed", "authorizationTimedOut", "saleFailed", "saleTimedOut")) return "FAILED";
  return null;
}
