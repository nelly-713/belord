import "server-only";

// Server-only Worldpay configuration. Never import this from client components.
const HOSTS = {
  try: "https://try.access.worldpay.com",
  live: "https://access.worldpay.com",
} as const;

function required(name: string): string {
  const value = process.env[name];
  if (!value) throw new Error(`Missing environment variable ${name}`);
  return value;
}

const env: keyof typeof HOSTS = process.env.WORLDPAY_ENV === "live" ? "live" : "try";

export const worldpayConfig = {
  env,
  baseUrl: HOSTS[env],
  apiVersion: "2024-06-01",
  get username() { return required("WORLDPAY_API_USERNAME"); },
  get password() { return required("WORLDPAY_API_PASSWORD"); },
  get entity() { return required("WORLDPAY_ENTITY"); },
  // Statement narrative: 1–24 chars of letters, digits, space , . / -
  narrative:
    (process.env.WORLDPAY_NARRATIVE ?? "JEWELRY STORE").replace(/[^a-zA-Z0-9 ,./-]/g, "").slice(0, 24) ||
    "JEWELRY STORE",
  siteUrl: (process.env.NEXT_PUBLIC_SITE_URL ?? "http://localhost:3000").replace(/\/$/, ""),
};
