import type { BrowserDeviceData } from "./worldpay/types";

export interface BrowserInput {
  acceptHeader?: string;
  language?: string;
  screenHeight?: number;
  screenWidth?: number;
  colorDepth?: number;
  timeZoneOffset?: number;
  javaEnabled?: boolean;
}

const COLOR_DEPTHS = [1, 4, 8, 15, 16, 24, 32, 48];
const DEFAULT_ACCEPT = "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8";

// 3DS browser data — better data means fewer challenges for genuine customers.
export function buildDeviceData(userAgent: string | null, b: BrowserInput): BrowserDeviceData {
  const depth =
    b.colorDepth === undefined
      ? undefined
      : COLOR_DEPTHS.reduce((best, d) => (d <= b.colorDepth! ? d : best), COLOR_DEPTHS[0]);
  return {
    channel: "browser",
    acceptHeader: (b.acceptHeader || DEFAULT_ACCEPT).slice(0, 2048),
    userAgentHeader: (userAgent || "unknown").slice(0, 2048),
    browserLanguage: b.language?.slice(0, 8),
    browserScreenHeight: b.screenHeight,
    browserScreenWidth: b.screenWidth,
    browserColorDepth: depth,
    browserJavaEnabled: b.javaEnabled ?? false,
    browserJavascriptEnabled: true,
    timeZone: b.timeZoneOffset === undefined ? undefined : String(b.timeZoneOffset),
  };
}
