export default function Page() {
  return <main><h1>Collection</h1>{/* TODO */}</main>;
}
