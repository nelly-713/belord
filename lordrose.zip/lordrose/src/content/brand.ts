// Everything Lord Rose says on the site, in one place.
// Lines marked REPLACE are placeholders until the client provides their own words.

export const brand = {
  name: "Lord Rose",
  // REPLACE: the client's tagline (one short line under the name on the homepage)
  tagline: "Fine jewelry, made to be kept.",
  // REPLACE: one or two sentences for search engines and link previews
  description: "Fine jewelry by Lord Rose.",
  // Short phrases in the moving band under the photo (true store features — edit freely)
  band: ["Fine jewelry", "Insured shipping", "Signature on delivery", "Free shipping over $500"],
  // REPLACE: the client's contact email
  email: "hello@lordrose.com",

  about: {
    eyebrow: "Our story",
    // REPLACE: a headline for the About page
    title: "[A line that sums up what Lord Rose stands for]",
    // REPLACE: the founder's story, one paragraph per entry
    paragraphs: [
      "[How Lord Rose began: who started it, where, and why.]",
      "[How the pieces are made: materials, stones, the hands involved.]",
      "[What a customer should feel when they wear a Lord Rose piece.]",
    ],
    founder: {
      name: "[Founder name]", // REPLACE
      role: "Founder & designer", // REPLACE if different
    },
    // REPLACE: short line used on the homepage teaser
    teaser: "[One or two sentences introducing the founder and the house.]",
  },
};

export const CATEGORY_LABELS: Record<string, string> = {
  RING: "Rings",
  NECKLACE: "Necklaces",
  PENDANT: "Pendants",
  EARRINGS: "Earrings",
  BRACELET: "Bracelets",
  WATCH: "Watches",
};
