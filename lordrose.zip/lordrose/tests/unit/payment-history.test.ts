import { describe, expect, it } from "vitest";
import { statusFromPaymentHistory } from "@/lib/payments/history";

const ev = (eventName: string, extra: object = {}) => ({ eventName, ...extra });

describe("status from Worldpay payment history", () => {
  it("authorized, then sent for settlement", () => {
    expect(statusFromPaymentHistory([ev("authorizationRequested"), ev("authorizationSucceeded")], 1000)).toBe("AUTHORIZED");
    expect(statusFromPaymentHistory([ev("authorizationSucceeded"), ev("settlementRequested")], 1000)).toBe("SENT_FOR_SETTLEMENT");
  });
  it("refused and failed", () => {
    expect(statusFromPaymentHistory([ev("authorizationRefused")], 1000)).toBe("REFUSED");
    expect(statusFromPaymentHistory([ev("authorizationTimedOut")], 1000)).toBe("FAILED");
  });
  it("full vs partial refunds", () => {
    const settled = [ev("authorizationSucceeded"), ev("settlementRequested")];
    expect(statusFromPaymentHistory([...settled, ev("refundRequested")], 1000)).toBe("REFUNDED");
    expect(statusFromPaymentHistory([...settled, ev("refundRequested", { type: "partialRefund", value: { amount: 400 } })], 1000)).toBe("SENT_FOR_SETTLEMENT");
    expect(statusFromPaymentHistory([...settled,
      ev("refundRequested", { type: "partialRefund", value: { amount: 400 } }),
      ev("refundRequested", { type: "partialRefund", value: { amount: 600 } })], 1000)).toBe("REFUNDED");
  });
  it("cancellations and reversals", () => {
    expect(statusFromPaymentHistory([ev("authorizationSucceeded"), ev("cancellationRequested")], 1000)).toBe("CANCELLED");
    expect(statusFromPaymentHistory([ev("authorizationSucceeded"), ev("reversalRequested")], 1000)).toBe("CANCELLED");
    expect(statusFromPaymentHistory([ev("authorizationSucceeded"), ev("settlementRequested"), ev("reversalRequested")], 1000)).toBe("REFUNDED");
  });
  it("nothing useful yet", () => {
    expect(statusFromPaymentHistory([ev("authorizationRequested")], 1000)).toBeNull();
  });
});
