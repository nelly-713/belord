import Link from "next/link";
import ProductCard from "@/components/product/ProductCard";
import { brand } from "@/content/brand";
import { listProducts } from "@/lib/catalog";

export const dynamic = "force-dynamic";

export default async function Home() {
  const featured = await listProducts({ take: 6 });
  const band = [...brand.band, ...brand.band]; // doubled so the loop is seamless

  return (
    <main>
      <section className="lr-hero">
        {/* eslint-disable-next-line @next/next/no-img-element */}
        <img className="lr-hero__img" src="/images/brand/hero.jpg" alt="" fetchPriority="high" />
        <div className="lr-hero__top">
          <h1 className="lr-hero__mark">{brand.name}</h1>
          <p className="lr-hero__tagline">{brand.tagline}</p>
        </div>
        <div className="lr-hero__bottom">
          <Link className="lr-btn lr-btn--light" href="/shop">Enter the boutique</Link>
          <span className="lr-hero__scroll" aria-hidden="true">Scroll</span>
        </div>
      </section>

      <div className="lr-band" aria-label={brand.band.join(", ")}>
        <div className="lr-band__track" aria-hidden="true">
          {band.map((phrase, i) => (
            <span className="lr-band__item" key={i}>{phrase}</span>
          ))}
        </div>
      </div>

      <section className="lr-section">
        <div className="lr-wrap">
          <div className="lr-section__head">
            <div>
              <p className="lr-eyebrow">The boutique</p>
              <h2>Featured pieces</h2>
            </div>
            <Link className="lr-link" href="/shop">View all pieces</Link>
          </div>
          {featured.length ? (
            <div className="lr-grid">
              {featured.map((p) => <ProductCard key={p.slug} product={p} />)}
            </div>
          ) : (
            <p className="lr-empty">New pieces are coming soon.</p>
          )}
        </div>
      </section>

      <section className="lr-section" style={{ paddingTop: 0 }}>
        <div className="lr-wrap lr-split">
          <div className="lr-split__img" role="img" aria-label="Detail of light through a cushion-cut diamond" />
          <div className="lr-split__body">
            <p className="lr-eyebrow">{brand.about.eyebrow}</p>
            <h2>{brand.about.founder.name}</h2>
            <p style={{ margin: 0 }}>{brand.about.teaser}</p>
            <div><Link className="lr-btn lr-btn--dark" href="/about">Read our story</Link></div>
          </div>
        </div>
      </section>
    </main>
  );
}
