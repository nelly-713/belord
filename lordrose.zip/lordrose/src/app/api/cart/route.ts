import { NextResponse } from "next/server";
import { cartSchema } from "@/lib/validation/checkout";
import { priceCart, PricingError } from "@/lib/orders/pricing";

// POST { items } -> priced quote (lines, shipping, tax, total)
export async function POST(req: Request) {
  const parsed = cartSchema.safeParse(await req.json().catch(() => null));
  if (!parsed.success) return NextResponse.json({ error: "Invalid bag" }, { status: 400 });
  if (parsed.data.items.length === 0) return NextResponse.json({ quote: null });
  try {
    return NextResponse.json({ quote: await priceCart(parsed.data.items) });
  } catch (e) {
    if (e instanceof PricingError) return NextResponse.json({ error: e.message }, { status: 409 });
    throw e;
  }
}
