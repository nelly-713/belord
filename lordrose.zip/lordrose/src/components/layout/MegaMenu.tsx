export default function MegaMenu() {
  return <div>{/* TODO: MegaMenu */}</div>;
}
