"use client";
import Script from "next/script";
import { useRouter } from "next/navigation";
import { useCallback, useEffect, useRef, useState } from "react";
import { useCart } from "@/lib/cart/cart";
import type { CheckoutStep } from "@/lib/payments/status";
import { CHECKOUT_ID, CHECKOUT_SDK_URL } from "@/lib/payments/worldpay/public";
import { ChallengeFrame, DeviceDataCollector } from "./ThreeDSChallenge";
import styles from "./WorldpayCardForm.module.css";
import Spinner from "@/components/ui/Spinner";

interface WorldpayCheckout {
  generateSessionState: (cb: (error: unknown, sessionState: string) => void) => void;
  clearForm: (cb?: () => void) => void;
  remove: () => void;
}

declare global {
  interface Window {
    Worldpay?: {
      checkout: {
        init: (config: Record<string, unknown>, cb: (error: unknown, checkout: WorldpayCheckout) => void) => void;
      };
    };
  }
}

type Phase = "loading" | "ready" | "submitting" | "verifying" | "done";

export default function WorldpayCardForm({
  orderId,
  amountLabel,
  acceptHeader,
}: {
  orderId: string;
  amountLabel: string;
  acceptHeader: string;
}) {
  const router = useRouter();
  const { clear } = useCart();
  const checkoutRef = useRef<WorldpayCheckout | null>(null);
  const [sdkReady, setSdkReady] = useState(false);
  const [phase, setPhase] = useState<Phase>("loading");
  const [error, setError] = useState<string | null>(null);
  const [errorCount, setErrorCount] = useState(0);
  useEffect(() => {
    if (error) setErrorCount((n) => n + 1);
  }, [error]);
  const [name, setName] = useState("");
  const [ddc, setDdc] = useState<{ url: string; jwt: string; bin: string } | null>(null);
  const [challenge, setChallenge] = useState<{ url: string; jwt: string } | null>(null);

  // Mount Worldpay's secure card fields once the SDK script has loaded.
  useEffect(() => {
    if (!sdkReady || !window.Worldpay) return;
    if (!CHECKOUT_ID) {
      setError("Payments aren't configured yet (missing NEXT_PUBLIC_WORLDPAY_CHECKOUT_ID).");
      return;
    }
    let cancelled = false;
    window.Worldpay.checkout.init(
      {
        id: CHECKOUT_ID,
        form: "#card-form",
        fields: {
          pan: { selector: "#card-pan", placeholder: "Card number" },
          expiry: { selector: "#card-expiry", placeholder: "MM/YY" },
          cvv: { selector: "#card-cvv", placeholder: "CVC" },
        },
        styles: {
          input: { "font-size": "16px", color: "#1c1b19", "font-family": "system-ui, sans-serif" },
          "input.is-invalid": { color: "#b3261e" },
        },
        accessibility: { ariaLabel: { pan: "Card number", expiry: "Expiry date", cvv: "Security code" } },
        enablePanFormatting: true,
      },
      (err, checkout) => {
        if (cancelled) {
          checkout?.remove();
          return;
        }
        if (err) {
          console.error("Worldpay Checkout init failed", err);
          setError("We couldn't load the secure card form. Please refresh the page.");
          return;
        }
        checkoutRef.current = checkout;
        setPhase("ready");
      }
    );
    return () => {
      cancelled = true;
      checkoutRef.current?.remove();
      checkoutRef.current = null;
    };
  }, [sdkReady]);

  const handleStep = useCallback(
    (s: CheckoutStep) => {
      switch (s.step) {
        case "authorized":
          clear();
          setPhase("done");
          router.push(`/checkout/confirmation?order=${encodeURIComponent(orderId)}`);
          return;
        case "deviceData":
          setPhase("verifying");
          setDdc(s.ddc);
          return;
        case "challenge":
          setPhase("verifying");
          setDdc(null);
          setChallenge(s.challenge);
          return;
        case "refused":
          setDdc(null);
          setChallenge(null);
          setError(s.message);
          setPhase("ready");
          checkoutRef.current?.clearForm();
          return;
      }
    },
    [clear, orderId, router]
  );

  const post = useCallback(
    async (url: string, body: unknown) => {
      try {
        const res = await fetch(url, {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify(body),
        });
        const data = (await res.json().catch(() => null)) as CheckoutStep | null;
        handleStep(data && "step" in data ? data : { step: "refused", message: "Something went wrong. Please try again." });
      } catch {
        handleStep({ step: "refused", message: "Network error. Please check your connection and try again." });
      }
    },
    [handleStep]
  );

  function onSubmit(e: React.FormEvent) {
    e.preventDefault();
    setError(null);
    const checkout = checkoutRef.current;
    if (!checkout || phase !== "ready") return;
    if (!name.trim()) {
      setError("Enter the name on the card.");
      return;
    }
    setPhase("submitting");
    checkout.generateSessionState((err, sessionState) => {
      if (err) {
        setError("Please check your card details.");
        setPhase("ready");
        return;
      }
      void post("/api/checkout/payment", {
        orderId,
        sessionHref: sessionState,
        cardHolderName: name.trim(),
        browser: {
          acceptHeader,
          language: navigator.language,
          screenHeight: window.screen.height,
          screenWidth: window.screen.width,
          colorDepth: window.screen.colorDepth,
          timeZoneOffset: new Date().getTimezoneOffset(),
          javaEnabled: false,
        },
      });
    });
  }

  const onDeviceData = useCallback(
    (collectionReference?: string) => {
      setDdc(null);
      void post("/api/checkout/3ds", { step: "deviceData", orderId, collectionReference });
    },
    [orderId, post]
  );

  const onChallengeDone = useCallback(() => {
    setChallenge(null);
    void post("/api/checkout/3ds", { step: "challenge", orderId });
  }, [orderId, post]);

  const buttonText =
    phase === "loading" ? "Loading secure form…" : phase === "ready" ? `Pay ${amountLabel}` : phase === "verifying" ? "Verifying with your bank…" : "Processing…";

  return (
    <>
      <Script src={CHECKOUT_SDK_URL} strategy="afterInteractive" onReady={() => setSdkReady(true)} />
      <form id="card-form" className={`${styles.form} motion-fade-up`} onSubmit={onSubmit} noValidate>
        <label className={styles.label}>
          Name on card
          <input
            className={styles.input}
            value={name}
            onChange={(e) => setName(e.target.value)}
            autoComplete="cc-name"
            required
          />
        </label>
        <div className={styles.label}>
          <span>Card number</span>
          <section id="card-pan" className={`${styles.field}${phase === "loading" ? " motion-shimmer" : ""}`} />
        </div>
        <div className={styles.row}>
          <div className={styles.label}>
            <span>Expiry</span>
            <section id="card-expiry" className={`${styles.field}${phase === "loading" ? " motion-shimmer" : ""}`} />
          </div>
          <div className={styles.label}>
            <span>Security code</span>
            <section id="card-cvv" className={`${styles.field}${phase === "loading" ? " motion-shimmer" : ""}`} />
          </div>
        </div>
        {error && (
          <p role="alert" key={errorCount} className={`${styles.error} motion-shake`}>
            {error}
          </p>
        )}
        <button type="submit" className={styles.button} disabled={phase !== "ready"} aria-busy={phase === "submitting" || phase === "verifying"}>
          {phase !== "ready" && <Spinner />}
          <span>{buttonText}</span>
        </button>
        <p className={styles.hint}>Card details go straight to Worldpay&apos;s secure fields and never touch our servers.</p>
      </form>
      {ddc && <DeviceDataCollector ddc={ddc} onDone={onDeviceData} />}
      {challenge && <ChallengeFrame challenge={challenge} onDone={onChallengeDone} />}
    </>
  );
}
