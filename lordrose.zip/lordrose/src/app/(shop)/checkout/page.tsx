import CheckoutDetailsForm from "@/components/checkout/CheckoutDetailsForm";
import CheckoutSteps from "@/components/checkout/CheckoutSteps";

export default function CheckoutPage() {
  return (
    <main style={{ maxWidth: 1000, margin: "0 auto", padding: 16 }}>
      <CheckoutSteps current={1} />
      <h1>Checkout</h1>
      <CheckoutDetailsForm />
    </main>
  );
}
