import { NextResponse } from "next/server";
import { prisma } from "@/lib/db/prisma";
import { threeDSSchema } from "@/lib/validation/checkout";
import { completeChallenge, handleWorldpayResponse, paymentErrorResponse, supplyDeviceData, type CheckoutStep } from "@/lib/payments";
import type { WorldpayActions } from "@/lib/payments/worldpay/types";

// POST { step: "deviceData", orderId, collectionReference? } | { step: "challenge", orderId }
export async function POST(req: Request) {
  const parsed = threeDSSchema.safeParse(await req.json().catch(() => null));
  if (!parsed.success) return NextResponse.json({ error: "Invalid request" }, { status: 400 });
  const input = parsed.data;

  const payment = await prisma.payment.findFirst({
    where: { orderId: input.orderId, status: "AUTHENTICATING" },
    orderBy: { createdAt: "desc" },
  });
  if (!payment) {
    const body: CheckoutStep = { step: "refused", message: "This verification has expired. Please try again." };
    return NextResponse.json(body, { status: 409 });
  }

  const actions = (payment.actions ?? {}) as WorldpayActions;
  try {
    const res =
      input.step === "deviceData"
        ? await supplyDeviceData(actions, input.collectionReference)
        : await completeChallenge(actions);
    return NextResponse.json(await handleWorldpayResponse(payment.id, res));
  } catch (e) {
    return paymentErrorResponse(payment.id, e);
  }
}
