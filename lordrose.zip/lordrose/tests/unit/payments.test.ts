import { createHmac } from "node:crypto";
import { describe, expect, it } from "vitest";
import { buildDeviceData } from "@/lib/payments/device-data";
import { interpretOutcome, orderStatusFor, shouldApply, statusForEvent } from "@/lib/payments/status";
import { parseEvent, verifyEventSignature } from "@/lib/payments/worldpay/webhooks";

const body = JSON.stringify({ eventId: "e1", eventDetails: { type: "authorized", transactionReference: "JW-ABC-1" } });
const secret = "test-secret";
const hex = createHmac("sha256", secret).update(body).digest("hex");
const b64 = createHmac("sha256", secret).update(body).digest("base64");

describe("webhook signatures", () => {
  it("accepts hex and base64 HMAC-SHA256", () => {
    expect(verifyEventSignature(body, `k1/HmacSHA256/${hex}`, secret)).toBe(true);
    expect(verifyEventSignature(body, `k1/HmacSHA256/${b64}`, secret)).toBe(true);
  });
  it("matches by key id among several signatures", () => {
    expect(verifyEventSignature(body, `old/HmacSHA256/abc, k2/HmacSHA256/${hex}`, secret, "k2")).toBe(true);
    expect(verifyEventSignature(body, `k2/HmacSHA256/${hex}`, secret, "k1")).toBe(false);
  });
  it("rejects tampered bodies and missing headers", () => {
    expect(verifyEventSignature(body + " ", `k1/HmacSHA256/${hex}`, secret)).toBe(false);
    expect(verifyEventSignature(body, null, secret)).toBe(false);
  });
  it("parses events", () => {
    expect(parseEvent(body)?.eventDetails.type).toBe("authorized");
    expect(parseEvent("not json")).toBeNull();
  });
});

describe("payment status", () => {
  it("maps outcomes to next steps", () => {
    expect(interpretOutcome("authorized").step).toBe("authorized");
    expect(interpretOutcome("3dsDeviceDataRequired").step).toBe("deviceData");
    expect(interpretOutcome("3dsChallenged").step).toBe("challenge");
    expect(interpretOutcome("fraudHighRisk").step).toBe("refused");
  });
  it("never moves backwards", () => {
    expect(shouldApply("SETTLED", "AUTHORIZED")).toBe(false);
    expect(shouldApply("AUTHORIZED", "SETTLED")).toBe(true);
    expect(shouldApply("SENT_FOR_SETTLEMENT", "FAILED")).toBe(true);
    expect(shouldApply("SETTLED", "FAILED")).toBe(false);
    expect(shouldApply("FAILED", "AUTHORIZED")).toBe(true);
  });
  it("maps events and order status", () => {
    expect(statusForEvent("settled")).toBe("SETTLED");
    expect(statusForEvent("tokenCreated")).toBeNull();
    expect(orderStatusFor("AUTHORIZED", "PENDING_PAYMENT")).toBe("PAID");
    expect(orderStatusFor("AUTHORIZED", "SHIPPED")).toBeNull();
    expect(orderStatusFor("REFUSED", "PENDING_PAYMENT")).toBeNull();
  });
});

describe("3DS device data", () => {
  it("rounds color depth down to an allowed value", () => {
    expect(buildDeviceData("UA", { colorDepth: 30 }).browserColorDepth).toBe(24);
    expect(buildDeviceData(null, {}).userAgentHeader).toBe("unknown");
  });
});
