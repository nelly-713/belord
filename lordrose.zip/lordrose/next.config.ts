import type { NextConfig } from "next";

const nextConfig: NextConfig = {
  // Lets OpenNext bundle and patch Prisma for Cloudflare Workers.
  serverExternalPackages: ["@prisma/client", ".prisma/client"],
  async redirects() {
    return [
      {
        source: "/:path*",
        has: [{ type: "host", value: "www.lordrose.com" }],
        destination: "https://lordrose.com/:path*",
        permanent: true,
      },
    ];
  },
};

export default nextConfig;
