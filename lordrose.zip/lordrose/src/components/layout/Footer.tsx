import Link from "next/link";
import { brand } from "@/content/brand";

export default function Footer() {
  return (
    <footer className="lr-footer">
      <div className="lr-wrap">
        <div className="lr-footer__grid">
          <div>
            <p className="lr-footer__mark">{brand.name}</p>
            <p style={{ margin: 0 }}>{brand.email}</p>
          </div>
          <div>
            <h3>Shop</h3>
            <ul>
              <li><Link href="/shop">All pieces</Link></li>
              <li><Link href="/shop?category=RING">Rings</Link></li>
              <li><Link href="/shop?category=NECKLACE">Necklaces</Link></li>
              <li><Link href="/shop?category=EARRINGS">Earrings</Link></li>
            </ul>
          </div>
          <div>
            <h3>House</h3>
            <ul>
              <li><Link href="/about">About</Link></li>
              <li><Link href="/contact">Contact</Link></li>
            </ul>
          </div>
          <div>
            <h3>Care &amp; service</h3>
            <ul>
              <li><Link href="/shipping-returns">Shipping &amp; returns</Link></li>
              <li><Link href="/ring-size-guide">Ring size guide</Link></li>
              <li><Link href="/care-guide">Jewelry care</Link></li>
              <li><Link href="/faq">FAQ</Link></li>
            </ul>
          </div>
        </div>
        <p className="lr-footer__legal">© {new Date().getFullYear()} {brand.name}. All rights reserved.</p>
      </div>
    </footer>
  );
}
