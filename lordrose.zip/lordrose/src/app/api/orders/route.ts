// TODO: orders API
export async function GET() {
  return Response.json({ todo: "orders" }, { status: 501 });
}
