export default function Page() {
  return <main><h1>Shipping & Returns</h1>{/* TODO */}</main>;
}
