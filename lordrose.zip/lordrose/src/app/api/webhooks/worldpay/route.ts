import { NextResponse } from "next/server";
import { parseEvent, verifyEventSignature } from "@/lib/payments/worldpay/webhooks";
import { processEvent } from "@/lib/payments/events";

export const runtime = "nodejs";

// Worldpay event notifications. Worldpay eCommerce (SMB) webhooks are not signed, so every
// event is confirmed with Worldpay's Payment Queries API before anything changes (see processEvent).
// If Worldpay ever gives you a signing secret, set WORLDPAY_WEBHOOK_SECRET and it is checked too.
// Worldpay delivers events in a queue and expects a 200 within ~10s; it retries failures.
export async function POST(req: Request) {
  const raw = await req.text();
  const secret = process.env.WORLDPAY_WEBHOOK_SECRET;

  if (secret) {
    const ok = verifyEventSignature(
      raw,
      req.headers.get("event-signature"),
      secret,
      process.env.WORLDPAY_WEBHOOK_KEY_ID || undefined
    );
    if (!ok) return new NextResponse("invalid signature", { status: 401 });
  }

  const event = parseEvent(raw);
  if (!event) return new NextResponse("ok"); // acknowledge junk so it doesn't block the queue

  try {
    await processEvent(event);
  } catch (e) {
    console.error("Worldpay webhook processing failed", event.eventId, e);
    return new NextResponse("error", { status: 500 }); // Worldpay will retry
  }
  return new NextResponse("ok");
}
