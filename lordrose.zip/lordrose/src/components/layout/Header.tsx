"use client";
import Link from "next/link";
import { usePathname } from "next/navigation";
import { useCart } from "@/lib/cart/cart";
import { brand } from "@/content/brand";

// Sits on top of the photo on the homepage; a plain bar everywhere else.
export default function Header() {
  const pathname = usePathname();
  const { count } = useCart();
  const overlay = pathname === "/";

  return (
    <header className={`lr-header${overlay ? " lr-header--overlay" : ""}`}>
      <div className="lr-wrap lr-header__row">
        <Link href="/" className="lr-header__mark" aria-label={`${brand.name} home`}>
          {brand.name}
        </Link>
        <nav className="lr-nav" aria-label="Main">
          <Link href="/shop">Shop</Link>
          <Link href="/about">About</Link>
          <Link href="/cart">
            Bag
            {count > 0 && (
              <span className="lr-bagcount" aria-label={`${count} items`}>
                <span>{count}</span>
              </span>
            )}
          </Link>
        </nav>
      </div>
    </header>
  );
}
