import "server-only";
import { prisma } from "@/lib/db/prisma";
import type { CardProduct } from "@/components/product/ProductCard";

const CATEGORIES = ["RING", "NECKLACE", "PENDANT", "EARRINGS", "BRACELET", "WATCH"] as const;
export type CategoryName = (typeof CATEGORIES)[number];
export const isCategory = (v: unknown): v is CategoryName => CATEGORIES.includes(v as CategoryName);

export async function listProducts(opts: { category?: CategoryName; take?: number } = {}): Promise<CardProduct[]> {
  const products = await prisma.product.findMany({
    where: opts.category ? { category: opts.category } : {},
    orderBy: { createdAt: "desc" },
    take: opts.take,
    include: {
      variants: { orderBy: { priceMinor: "asc" }, take: 1 },
      images: { orderBy: { position: "asc" }, take: 1 },
    },
  });
  return products.map((p) => ({
    slug: p.slug,
    name: p.name,
    category: p.category,
    fromPriceMinor: p.variants[0]?.priceMinor,
    currency: p.variants[0]?.currency,
    image: p.images[0] ? { url: p.images[0].url, alt: p.images[0].alt } : undefined,
  }));
}

export async function categoriesInStock(): Promise<CategoryName[]> {
  const rows = await prisma.product.findMany({ distinct: ["category"], select: { category: true } });
  return CATEGORIES.filter((c) => rows.some((r) => r.category === c));
}
