import "server-only";
import { authHeader, WorldpayError } from "./client";
import { worldpayConfig } from "./config";

// Payment Queries API: the authoritative record of what happened to a payment.
const ACCEPT = "application/vnd.worldpay.payment-queries-v1.hal+json";

export interface QueriedEvent {
  eventName: string;
  timestamp?: string;
  type?: string;
  value?: { amount: number; currency: string };
}

export interface QueriedPayment {
  paymentId: string;
  transactionReference: string;
  lastEvent?: string;
  value?: { amount: number; currency: string };
  events?: QueriedEvent[];
  _links?: { self?: { href: string } };
}

async function get<T>(path: string): Promise<T> {
  const base = new URL(worldpayConfig.baseUrl);
  const url = new URL(path, base);
  if (url.origin !== base.origin) throw new Error(`Refusing to call non-Worldpay host ${url.origin}`);
  const res = await fetch(url, {
    headers: { Authorization: authHeader(), Accept: ACCEPT },
    cache: "no-store",
    // Worldpay wants a webhook answered within ~10s; two lookups must fit inside that.
    signal: AbortSignal.timeout(4_000),
  });
  const text = await res.text();
  if (!res.ok) throw new WorldpayError(res.status, text);
  return JSON.parse(text) as T;
}

export async function findPaymentByReference(transactionReference: string): Promise<QueriedPayment | null> {
  const list = await get<{ _embedded?: { payments?: QueriedPayment[] } }>(
    `/paymentQueries/payments?transactionReference=${encodeURIComponent(transactionReference)}`
  );
  const summary = list._embedded?.payments?.[0];
  if (!summary) return null;
  const href = summary._links?.self?.href ?? `/paymentQueries/payments/${encodeURIComponent(summary.paymentId)}`;
  return get<QueriedPayment>(href); // full record, including the events history
}
