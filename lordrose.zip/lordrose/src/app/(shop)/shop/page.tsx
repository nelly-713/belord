import Link from "next/link";
import type { Metadata } from "next";
import ProductCard from "@/components/product/ProductCard";
import { CATEGORY_LABELS } from "@/content/brand";
import { categoriesInStock, isCategory, listProducts } from "@/lib/catalog";

export const dynamic = "force-dynamic";
export const metadata: Metadata = { title: "The boutique" };

export default async function ShopPage({ searchParams }: { searchParams: Promise<{ category?: string }> }) {
  const { category } = await searchParams;
  const active = isCategory(category) ? category : undefined;
  const [products, categories] = await Promise.all([listProducts({ category: active }), categoriesInStock()]);

  return (
    <main className="lr-section">
      <div className="lr-wrap">
        <p className="lr-eyebrow">The boutique</p>
        <h1 style={{ margin: "6px 0 24px", fontSize: "clamp(34px, 5vw, 56px)" }}>
          {active ? CATEGORY_LABELS[active] : "All pieces"}
        </h1>
        {categories.length > 1 && (
          <nav className="lr-chips" aria-label="Categories">
            <Link className="lr-chip" href="/shop" aria-current={!active ? "page" : undefined}>All</Link>
            {categories.map((c) => (
              <Link key={c} className="lr-chip" href={`/shop?category=${c}`} aria-current={active === c ? "page" : undefined}>
                {CATEGORY_LABELS[c]}
              </Link>
            ))}
          </nav>
        )}
        {products.length ? (
          <div className="lr-grid">
            {products.map((p) => <ProductCard key={p.slug} product={p} />)}
          </div>
        ) : (
          <p className="lr-empty">No pieces here yet.</p>
        )}
      </div>
    </main>
  );
}
