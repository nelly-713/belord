export interface CartItem {
  variantId: string;
  quantity: number;
  engraving?: string;
}

export interface QuoteLine {
  variantId: string;
  sku: string;
  name: string;
  slug: string;
  description: string;
  quantity: number;
  unitPriceMinor: number;
  lineTotalMinor: number;
  engraving: string | null;
}

export interface CartQuote {
  lines: QuoteLine[];
  currency: string;
  subtotalMinor: number;
  shippingMinor: number;
  taxMinor: number;
  totalMinor: number;
}
