export default function CartLineItem() {
  return <div>{/* TODO: CartLineItem */}</div>;
}
