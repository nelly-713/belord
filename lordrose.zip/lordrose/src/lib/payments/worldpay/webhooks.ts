import { createHmac, timingSafeEqual } from "node:crypto";

// Access Worldpay Events payload (HAL JSON). Only the fields we use are typed.
export interface WorldpayEvent {
  eventId: string;
  eventTimestamp?: string;
  eventDetails: {
    classification?: string;
    type: string;
    transactionReference?: string;
    downstreamReference?: string;
    amount?: { value: number; currencyCode: string };
    [key: string]: unknown;
  };
}

export interface ParsedSignature {
  keyId: string;
  hashFunction: string;
  signature: string;
}

// Header format: {keyId}/{hashFunction}/{signature}, possibly several comma-separated.
export function parseSignatureHeader(header: string): ParsedSignature[] {
  return header
    .split(",")
    .map((part) => part.trim())
    .map((part) => {
      const [keyId, hashFunction, ...rest] = part.split("/");
      return { keyId: keyId ?? "", hashFunction: hashFunction ?? "", signature: rest.join("/") };
    })
    .filter((s) => s.keyId && s.hashFunction && s.signature);
}

function safeEqual(a: string, b: string) {
  const A = Buffer.from(a);
  const B = Buffer.from(b);
  return A.length === B.length && timingSafeEqual(A, B);
}

// HMAC-SHA256 over the raw body. Accepts hex or base64 encoding.
// Confirm the exact encoding with your Worldpay Implementation Manager when they enable signing.
export function verifyEventSignature(
  rawBody: string,
  header: string | null,
  secret: string,
  expectedKeyId?: string
): boolean {
  if (!header) return false;
  const digest = createHmac("sha256", secret).update(rawBody, "utf8").digest();
  const hex = digest.toString("hex");
  const b64 = digest.toString("base64");
  return parseSignatureHeader(header).some((sig) => {
    if (expectedKeyId && sig.keyId !== expectedKeyId) return false;
    if (!sig.hashFunction.toLowerCase().includes("sha256")) return false;
    return safeEqual(sig.signature.toLowerCase(), hex) || safeEqual(sig.signature, b64);
  });
}

export function parseEvent(raw: string): WorldpayEvent | null {
  try {
    const data = JSON.parse(raw);
    if (typeof data?.eventId !== "string" || typeof data?.eventDetails?.type !== "string") return null;
    return data as WorldpayEvent;
  } catch {
    return null;
  }
}
