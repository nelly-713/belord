import { cache } from "react";
import { PrismaClient } from "@prisma/client";
import { PrismaNeon } from "@prisma/adapter-neon";

const usesNeon = () => /\.neon\.tech\b/.test(process.env.DATABASE_URL ?? "");

function create() {
  const url = process.env.DATABASE_URL ?? "";
  return usesNeon() ? new PrismaClient({ adapter: new PrismaNeon({ connectionString: url }) }) : new PrismaClient();
}

const perRequest = cache(create);
const g = globalThis as unknown as { prisma?: PrismaClient };

function client(): PrismaClient {
  if (usesNeon()) return perRequest();
  return (g.prisma ??= create());
}

// Same `prisma` import as before; it picks the right client at call time.
export const prisma = new Proxy({} as PrismaClient, {
  get(_target, prop) {
    const c = client();
    const value = Reflect.get(c, prop);
    return typeof value === "function" ? value.bind(c) : value;
  },
});
