// TODO: products API
export async function GET() {
  return Response.json({ todo: "products" }, { status: 501 });
}
