import "server-only";
import { Prisma, type PaymentStatus } from "@prisma/client";
import { prisma } from "@/lib/db/prisma";
import { orderStatusFor, shouldApply } from "@/lib/payments/status";
import { cancelPayment, refundPayment, settlePayment } from "@/lib/payments/worldpay/payments";
import type { WorldpayActions } from "@/lib/payments/worldpay/types";

// Move an order to PAID exactly once, decrementing stock in the same transaction.
export async function markOrderPaid(orderId: string) {
  await prisma.$transaction(async (tx) => {
    const moved = await tx.order.updateMany({
      where: { id: orderId, status: "PENDING_PAYMENT" },
      data: { status: "PAID" },
    });
    if (moved.count === 0) return;
    const items = await tx.orderItem.findMany({ where: { orderId } });
    for (const item of items) {
      await tx.variant.update({ where: { id: item.variantId }, data: { stock: { decrement: item.quantity } } });
    }
  });
}

// Apply a payment status from an API response or webhook. Never moves backwards.
export async function applyPaymentStatus(
  paymentId: string,
  next: PaymentStatus,
  extra: { worldpayPaymentId?: string; actions?: WorldpayActions; raw?: unknown }
) {
  const payment = await prisma.payment.findUnique({ where: { id: paymentId }, include: { order: true } });
  if (!payment || !shouldApply(payment.status, next)) return;

  await prisma.payment.update({
    where: { id: paymentId },
    data: {
      status: next,
      worldpayPaymentId: extra.worldpayPaymentId ?? undefined,
      actions: extra.actions ? (extra.actions as Prisma.InputJsonValue) : undefined,
      rawLastEvent: extra.raw ? (extra.raw as Prisma.InputJsonValue) : undefined,
    },
  });

  const target = orderStatusFor(next, payment.order.status);
  if (target === "PAID") await markOrderPaid(payment.orderId);
  else if (target) await prisma.order.update({ where: { id: payment.orderId }, data: { status: target } });
}

async function latestPayment(orderId: string, statuses: PaymentStatus[]) {
  return prisma.payment.findFirst({
    where: { orderId, status: { in: statuses } },
    orderBy: { createdAt: "desc" },
  });
}

// Capture the money. Call this when the order ships (authorizations expire after a few days,
// so don't leave orders unshipped and unsettled for long).
export async function settleOrder(orderId: string) {
  const payment = await latestPayment(orderId, ["AUTHORIZED"]);
  if (!payment) throw new Error("No authorized payment to settle");
  const res = await settlePayment(payment.actions as WorldpayActions);
  await applyPaymentStatus(payment.id, "SENT_FOR_SETTLEMENT", { actions: res._actions, raw: res });
}

// Release an authorization without charging (e.g. order cancelled before shipping).
export async function cancelOrderPayment(orderId: string) {
  const payment = await latestPayment(orderId, ["AUTHORIZED"]);
  if (!payment) throw new Error("No authorized payment to cancel");
  const res = await cancelPayment(payment.actions as WorldpayActions);
  await applyPaymentStatus(payment.id, "CANCELLED", { actions: res._actions, raw: res });
}

// Full refund after settlement. The "refunded" webhook marks the order refunded.
export async function refundOrder(orderId: string) {
  const payment = await latestPayment(orderId, ["SENT_FOR_SETTLEMENT", "SETTLED"]);
  if (!payment) throw new Error("No settled payment to refund");
  const res = await refundPayment(payment.actions as WorldpayActions);
  await prisma.payment.update({
    where: { id: payment.id },
    data: { actions: (res._actions ?? payment.actions ?? undefined) as Prisma.InputJsonValue | undefined, rawLastEvent: res as Prisma.InputJsonValue },
  });
}
