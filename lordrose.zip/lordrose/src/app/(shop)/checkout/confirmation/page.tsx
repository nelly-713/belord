import Link from "next/link";
import { notFound } from "next/navigation";
import { prisma } from "@/lib/db/prisma";
import { formatMoney } from "@/lib/money";
import CheckoutSteps from "@/components/checkout/CheckoutSteps";
import SuccessCheck from "@/components/checkout/SuccessCheck";

export const dynamic = "force-dynamic";

export default async function ConfirmationPage({ searchParams }: { searchParams: Promise<{ order?: string }> }) {
  const { order: orderId } = await searchParams;
  if (!orderId) notFound();
  const order = await prisma.order.findUnique({ where: { id: orderId } });
  if (!order) notFound();

  const paid = !["PENDING_PAYMENT", "CANCELLED"].includes(order.status);

  return (
    <main style={{ maxWidth: 640, margin: "0 auto", padding: 16 }}>
      <CheckoutSteps current={paid ? 3 : 2} />
      {paid ? (
        <>
          <SuccessCheck />
          <h1 className="motion-fade-up">Thank you — your order is confirmed</h1>
          <p>Order <strong>{order.number}</strong> · {formatMoney(order.totalMinor, order.currency)}</p>
          <p>We&apos;ve sent a confirmation to {order.email}. Your piece will ship insured, with signature on delivery.</p>
        </>
      ) : order.status === "CANCELLED" ? (
        <>
          <h1>This order was cancelled</h1>
          <p>If you think this is a mistake, please contact us and quote order {order.number}.</p>
        </>
      ) : (
        <>
          <h1>We&apos;re confirming your payment</h1>
          <p>This usually takes a moment. Refresh this page, or <Link href={`/checkout/payment?order=${order.id}`}>return to payment</Link>.</p>
        </>
      )}
      <p><Link href="/">Continue shopping</Link></p>
    </main>
  );
}
