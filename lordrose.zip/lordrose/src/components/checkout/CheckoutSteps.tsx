import type { CSSProperties } from "react";

const STEPS = ["Bag", "Details", "Payment", "Confirmed"];

// Progress bar that slides from the previous step to this one each time a page loads.
export default function CheckoutSteps({ current }: { current: number }) {
  const pct = (i: number) => `${(Math.max(i, 0) / (STEPS.length - 1)) * 100}%`;
  const fill = { "--from": pct(current - 1), "--to": pct(current) } as CSSProperties;

  return (
    <nav aria-label="Checkout progress" className="checkout-steps">
      <div className="checkout-steps__track">
        <div className="checkout-steps__fill" style={fill} />
      </div>
      <ol>
        {STEPS.map((label, i) => (
          <li
            key={label}
            className={i < current ? "is-done" : i === current ? "is-current" : undefined}
            aria-current={i === current ? "step" : undefined}
          >
            <span className="checkout-steps__dot">{i < current ? "✓" : i + 1}</span>
            <span>{label}</span>
          </li>
        ))}
      </ol>
    </nav>
  );
}
